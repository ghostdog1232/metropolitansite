# Lead Generation Flow — настройка

Формата (три полета: име на бизнеса, име, имейл) и модалът „Вземи оферта" изпращат към `netlify/functions/submit-lead.js`, която:
1. записва запитването в Supabase (`leads`),
2. праща вътрешна нотификация с всички данни до `NOTIFY_EMAIL`,
3. праща брандиран автоматичен имейл до клиента с линк към `brief.html` + обещание за оферта до 24 ч.

## 1. Supabase
SQL Editor → изпълнете `supabase/leads_migration.sql` (нови колони + таблица `briefs`).

## 2. Имейл — изберете начин

**Вариант A — Gmail (работи веднага, без имейл на домейна)**
1. В Google акаунта на `office@metropolitandigital.bg` включете „2-Step Verification".
2. Отворете https://myaccount.google.com/apppasswords → създайте „App password" (16 символа).
3. В Netlify задайте `SMTP_USER` = Gmail адреса и `SMTP_PASS` = App password-а.
   Имейлите ще излизат от този Gmail адрес (лимит ~500 на ден – напълно достатъчно за запитвания).

**Вариант B — Resend (по-професионален, когато имате имейл на домейна)**
1. https://resend.com → Domains → верифицирайте `metropolitandigital.bg` (SPF/DKIM записи).
2. Задайте `RESEND_API_KEY` и `FROM_EMAIL` (напр. `Metropolitan Digital <office@metropolitandigital.bg>`).
(Ако са зададени и двата варианта, се ползва Gmail.)

## 3. Netlify → Site configuration → Environment variables
| Променлива | Стойност |
|---|---|
| `SMTP_USER`, `SMTP_PASS` | Вариант A |
| `RESEND_API_KEY`, `FROM_EMAIL` | Вариант B |
| `NOTIFY_EMAIL` | по желание – служебен имейл за нотификации (по подразбиране = `SMTP_USER`) |
| `SUPABASE_SERVICE_KEY` | по желание – service role ключ (иначе се ползва публичният anon) |
| `BRIEF_URL`, `SITE_URL` | по желание (по подразбиране `…/brief.html`, `https://metropolitandigital.bg`) |

## 4. Деплой
Netlify функциите **не се качват с drag-and-drop**. Качете чрез Git (свързано repo) или Netlify CLI (`netlify deploy --prod`).
Без функцията формата пак записва запитването в Supabase, но **не се изпращат имейли**.

| `LEAD_MAGNET_URL` | публичен линк към PDF чеклиста (лийд магнит фуния) |
| `CALENDLY_URL` | линк към календара за имейлите (и в `js/config.js` за сайта) |
| `PROMO_TEXT` / `PROMO_UNTIL` | бонус в автоматичните имейлове (по подразбиране: 3 визии-карусели + текстове до 2026-11-30). За да го изключите по-рано, задайте `PROMO_UNTIL` с минала дата. След крайната дата бонусът изчезва от имейлите автоматично |
