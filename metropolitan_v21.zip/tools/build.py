#!/usr/bin/env python3
"""One-off sitewide patcher (idempotent-ish: run once on the original v14 files)."""
import re, glob, json, os, html
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
BASE = 'https://metropolitandigital.bg'
ORG_ID = BASE + '/#organization'
OG = BASE + '/images/og-cover.png'
NOINDEX = {'admin.html', 'thank-you.html', 'brief.html', 'service-details.html', 'portfolio-details.html'}

META = {
 'index.html': ('Дигитална агенция: SEO, реклама, сайтове | Metropolitan Digital',
   'Metropolitan Digital — дигитална агенция за SEO, реклама, социални мрежи, брандинг и уеб сайтове. Ясни цели, прозрачни отчети и оферта до 24 часа.'),
 'services.html': (None, 'Всички услуги на Metropolitan Digital: SEO, реклама, социални мрежи, маркетинг план, видео, брандинг, PR и изработване на сайтове. Оферта до 24 часа.'),
 'portfolio.html': (None, 'Избрани проекти на Metropolitan Digital — брандинг, уеб и дигитални кампании. Вижте какво можем да направим за вашия бизнес.'),
}
def rd(f): return open(f, encoding='utf-8').read().replace('\r\n', '\n')
def wr(f, s): open(f, 'w', encoding='utf-8', newline='\n').write(s)
def esc(x): return html.escape(x, quote=True)

def ld(obj): return '<script type="application/ld+json">' + json.dumps(obj, ensure_ascii=False) + '</script>'

ORG = {"@context": "https://schema.org", "@type": "ProfessionalService", "@id": ORG_ID,
  "name": "Metropolitan Digital", "legalName": "Метрополитан ООД", "url": BASE + "/",
  "logo": BASE + "/images/logo.png", "image": OG,
  "telephone": "+359896496164", "email": "metropolitandigitall@gmail.com",
  "identifier": "207499878", "areaServed": {"@type": "Country", "name": "България"},
  "sameAs": ["https://www.facebook.com/metropolitandigitall/", "https://www.instagram.com/metropolitan_digital"],
  "description": "Дигитална агенция за SEO, реклама, социални мрежи, брандинг, видео и изработване на сайтове."}
# [ПОПЪЛНИ: address / foundingDate / aggregateRating — добавете само верифицирани данни]

def breadcrumb(items):
    return {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": i + 1, "name": n, "item": u} for i, (n, u) in enumerate(items)]}

def process(f):
    s = rd(f)
    # --- remove unconditional trackers (replaced by js/consent.js) ---
    s = re.sub(r'(<!-- Google Analytics -->\s*)?<script async src="https://www\.googletagmanager\.com/gtag/js\?id=G-QEL23Z1MJH"></script>\s*<script>.*?</script>\s*', '', s, flags=re.S)
    s = re.sub(r'(<!--\s*Meta Pixel Code\s*-->)?\s*<script>\s*!function\(f,b,e,v,n,t,s\).*?</noscript>\s*(<!--\s*End Meta Pixel Code\s*-->)?', '', s, flags=re.S)
    # --- strip old social/canonical meta ---
    s = re.sub(r'\s*<meta (property|name)="(og|twitter):[^>]*>', '', s)
    s = re.sub(r'\s*<link rel="canonical"[^>]*>', '', s)
    s = re.sub(r'\s*<!-- (Open Graph / Facebook|Twitter) -->', '', s)
    s = s.replace('| Metropolitan Agency', '| Metropolitan Digital')
    t = re.search(r'<title>(.*?)</title>', s, re.S)
    title = t.group(1).strip()
    if f in META and META[f][0]:
        title = META[f][0]; s = re.sub(r'<title>.*?</title>', f'<title>{esc(title)}</title>', s, count=1, flags=re.S)
    d = re.search(r'<meta name="description" content="(.*?)"', s)
    desc = d.group(1) if d else ''
    if f in META and META[f][1]:
        desc = META[f][1]
        if d: s = re.sub(r'<meta name="description" content=".*?">', f'<meta name="description" content="{esc(desc)}">', s, count=1)
        else: s = s.replace('</title>', f'</title>\n    <meta name="description" content="{esc(desc)}">', 1)
    url = BASE + '/' if f == 'index.html' else f'{BASE}/{f}'
    head = ['    <script src="js/consent.js"></script>']
    if f in NOINDEX:
        if 'name="robots"' not in s: head.append('    <meta name="robots" content="noindex, follow">' if f != 'admin.html' else '    <meta name="robots" content="noindex, nofollow">')
    else:
        head.append(f'    <link rel="canonical" href="{url}">')
        head += [f'    <meta property="og:type" content="{"article" if f.startswith("blog-") else "website"}">',
                 '    <meta property="og:site_name" content="Metropolitan Digital">', '    <meta property="og:locale" content="bg_BG">',
                 f'    <meta property="og:url" content="{url}">', f'    <meta property="og:title" content="{esc(title)}">',
                 f'    <meta property="og:description" content="{esc(desc)}">', f'    <meta property="og:image" content="{OG}">',
                 '    <meta property="og:image:width" content="1200">', '    <meta property="og:image:height" content="630">',
                 '    <meta name="twitter:card" content="summary_large_image">', f'    <meta name="twitter:title" content="{esc(title)}">',
                 f'    <meta name="twitter:description" content="{esc(desc)}">', f'    <meta name="twitter:image" content="{OG}">']
        # structured data
        h1 = re.search(r'<h1[^>]*>(.*?)</h1>', s, re.S)
        h1t = re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', h1.group(1)))).strip() if h1 else title
        if f == 'index.html':
            head.append(ld(ORG)); head.append(ld({"@context": "https://schema.org", "@type": "WebSite", "@id": BASE + "/#website", "url": BASE + "/", "name": "Metropolitan Digital", "inLanguage": "bg-BG", "publisher": {"@id": ORG_ID}}))
        elif f.startswith('service-') and f != 'service-details.html':
            nm = title.split('|')[0].strip()
            head.append(ld({"@context": "https://schema.org", "@type": "Service", "name": nm, "serviceType": nm, "description": desc, "url": url, "provider": {"@id": ORG_ID, "@type": "ProfessionalService", "name": "Metropolitan Digital"}, "areaServed": {"@type": "Country", "name": "България"}}))
            head.append(ld(breadcrumb([("Начало", BASE + "/"), ("Услуги", BASE + "/services.html"), (nm, url)])))
        elif f.startswith('blog-'):
            head.append(ld({"@context": "https://schema.org", "@type": "BlogPosting", "headline": h1t[:110], "description": desc, "image": OG, "inLanguage": "bg-BG", "mainEntityOfPage": url, "author": {"@id": ORG_ID, "@type": "Organization", "name": "Metropolitan Digital"}, "publisher": {"@id": ORG_ID, "@type": "Organization", "name": "Metropolitan Digital", "logo": {"@type": "ImageObject", "url": BASE + "/images/logo.png"}}}))  # [ПОПЪЛНИ: datePublished / dateModified]
            head.append(ld(breadcrumb([("Начало", BASE + "/"), ("Блог", BASE + "/blog.html"), (h1t[:80], url)])))
        elif f in ('services.html', 'portfolio.html', 'blog.html'):
            head.append(ld(breadcrumb([("Начало", BASE + "/"), (title.split('|')[0].strip(), url)])))
    s = s.replace('</head>', '\n'.join(head) + '\n</head>', 1)
    # --- footer: cookie settings link + legal line ---
    if '<footer' in s:
        a, b = s.split('<footer', 1)
        b = re.sub(r'(<a href="terms\.html"[^>]*>[^<]*</a>)', r'\1\n                    <a href="#" data-cookie-settings data-t="footer_cookies">Настройки за бисквитки</a>', b, count=1)
        b = re.sub(r'(<p data-t="footer_rights">.*?</p>)', r'\1\n        <p class="footer-legal">Метрополитан ООД · ЕИК 207499878 · <a href="tel:+359896496164">+359 896 496 164</a></p>', b, count=1, flags=re.S)
        s = a + '<footer' + b
    wr(f, s)

for f in sorted(glob.glob('*.html')): process(f)

# ---------------- index.html: conversion edits ----------------
s = rd('index.html')
m = re.search(r'<!-- Testimonials Section -->.*?</section>', s, re.S)
open('docs/removed-testimonials.html', 'w', encoding='utf-8').write(m.group(0))
s = s.replace(m.group(0), '<!-- Отзивите са скрити до потвърждение на автентичност и съгласие на клиентите. [ПОПЪЛНИ: реални отзиви/логота/кейсове]. Оригиналът: docs/removed-testimonials.html -->')
s = s.replace('+240% ROI', 'Измерими резултати')
s = s.replace('Агенция от ново поколение', 'Дигитална агенция')
s = s.replace('Дигитално Съвършенство за <br>Модерни Брандове', 'Дигитален маркетинг, който носи <br>запитвания и клиенти')
s = s.replace('Ние създаваме иновативни изживявания, базирани на данни, които издигат вашия бранд и стимулират експоненциален растеж.', 'SEO, реклама, сайтове и съдържание под един покрив — с ясни, измерими цели. Получавате оферта до 24 часа и прозрачен отчет на всеки етап.')
s = s.replace('<a href="#contact" class="btn-primary btn-large glow-effect" data-t="hero_cta_primary">Изпрати запитване</a>', '<a href="#contact" class="btn-primary btn-large glow-effect" data-cta="hero_primary" data-t="hero_cta_primary">Получи безплатна оферта</a>')
s = s.replace('<a href="#why-choose" class="btn-secondary btn-large" data-t="hero_cta_secondary">Защо да ни изберете?</a>', '<a href="#process" class="btn-secondary btn-large" data-cta="hero_secondary" data-t="hero_cta_secondary">Как работим</a>')
s = s.replace('Нека създадем нещо <br>необикновено.', 'Разкажете ни <br>за проекта си.')
s = s.replace('Готови ли сте да издигнете дигиталното си присъствие? Свържете се с нашия екип от експерти.', 'Три полета — връщаме се с оферта до 24 часа. Без ангажимент.')
s = s.replace('>Получи оферта</button>', ' data-cta="contact_form_submit" data-t="contact_form_submit">Получи оферта до 24 ч.</button>'.replace(' data-t="contact_form_submit">', '>', 0), 1) if False else s
s = s.replace('data-t="contact_form_submit">Получи оферта</button>', 'data-cta="contact_form_submit" data-t="contact_form_submit">Получи оферта до 24 ч.</button>\n            <p class="form-privacy" data-t="contact_form_privacy">Изпращайки формата, се съгласявате с <a href="privacy-policy.html">Политиката за поверителност</a>.</p>')
s = s.replace('</ul>\n            <div class="social-links mt-4">', '<li><i class="fa-solid fa-phone"></i> <a href="tel:+359896496164" style="color:inherit;text-decoration:none;">+359 896 496 164</a></li>\n                </ul>\n            <div class="social-links mt-4">', 1) if '</ul>\n            <div class="social-links mt-4">' in s else s
s = s.replace('<button class="quote-float-btn" onclick="openQuoteModal()"', '<button class="quote-float-btn" data-cta="float_quote" onclick="openQuoteModal()"')
PROC = '''<!-- Process Section -->
    <section class="process section-padding" id="process">
        <div class="container container-center">
            <div class="section-header animate-on-scroll">
                <h2 data-t="process_title">Как <span class='highlight text-gradient'>работим</span></h2>
                <p data-t="process_subtitle">Четири ясни стъпки от първия контакт до старта на работата.</p>
            </div>
            <div class="process-grid">
                <div class="process-step animate-on-scroll"><span class="step-num">1</span><h3 data-t="process_1_title">Запитване</h3><p data-t="process_1_text">Оставяте име на бизнеса, име и имейл. Отнема по-малко от минута.</p></div>
                <div class="process-step animate-on-scroll"><span class="step-num">2</span><h3 data-t="process_2_title">Кратък бриф</h3><p data-t="process_2_text">Получавате имейл с линк към бриф от около 3 минути — цели, аудитория, бюджет и срок.</p></div>
                <div class="process-step animate-on-scroll"><span class="step-num">3</span><h3 data-t="process_3_title">Оферта до 24 часа</h3><p data-t="process_3_text">Връщаме се с конкретно предложение, съобразено с целите и бюджета ви.</p></div>
                <div class="process-step animate-on-scroll"><span class="step-num">4</span><h3 data-t="process_4_title">Старт и прозрачна отчетност</h3><p data-t="process_4_text">Започваме с ясен план и редовна обратна връзка с реални данни.</p></div>
            </div>
        </div>
    </section>

    '''
s = s.replace('<!-- Portfolio Section -->', PROC + '<!-- Portfolio Section -->', 1)
wr('index.html', s)

# ---------------- translations.js ----------------
T = open('js/translations.js', encoding='utf-8').read()
nl = '\r\n' if '\r\n' in T else '\n'
i_en = T.index('    en: {')
blocks = [T[:i_en], T[i_en:]]
BG = {'hero_badge': 'Дигитална агенция', 'hero_title': 'Дигитален маркетинг, който носи <br>запитвания и клиенти',
 'hero_subtitle': 'SEO, реклама, сайтове и съдържание под един покрив — с ясни, измерими цели. Получавате оферта до 24 часа и прозрачен отчет на всеки етап.',
 'hero_cta_primary': 'Получи безплатна оферта', 'hero_cta_secondary': 'Как работим', 'hero_floating_2': 'Измерими резултати',
 'contact_title': 'Разкажете ни <br>за проекта си.', 'contact_subtitle': 'Три полета — връщаме се с оферта до 24 часа. Без ангажимент.',
 'contact_form_submit': 'Получи оферта до 24 ч.'}
EN = {'hero_badge': 'Digital agency', 'hero_title': 'Digital marketing that brings <br>enquiries and customers',
 'hero_subtitle': 'SEO, advertising, websites and content under one roof — with clear, measurable goals. Get an offer within 24 hours and transparent reporting at every stage.',
 'hero_cta_primary': 'Get a free offer', 'hero_cta_secondary': 'How we work', 'hero_floating_2': 'Measurable results',
 'contact_title': 'Tell us about <br>your project.', 'contact_subtitle': 'Three fields — we come back with an offer within 24 hours. No obligation.',
 'contact_form_submit': 'Get an offer within 24h'}
NEW_BG = {'process_title': "Как <span class='highlight text-gradient'>работим</span>", 'process_subtitle': 'Четири ясни стъпки от първия контакт до старта на работата.',
 'process_1_title': 'Запитване', 'process_1_text': 'Оставяте име на бизнеса, име и имейл. Отнема по-малко от минута.',
 'process_2_title': 'Кратък бриф', 'process_2_text': 'Получавате имейл с линк към бриф от около 3 минути — цели, аудитория, бюджет и срок.',
 'process_3_title': 'Оферта до 24 часа', 'process_3_text': 'Връщаме се с конкретно предложение, съобразено с целите и бюджета ви.',
 'process_4_title': 'Старт и прозрачна отчетност', 'process_4_text': 'Започваме с ясен план и редовна обратна връзка с реални данни.',
 'contact_form_privacy': "Изпращайки формата, се съгласявате с <a href='privacy-policy.html'>Политиката за поверителност</a>.", 'footer_cookies': 'Настройки за бисквитки'}
NEW_EN = {'process_title': "How we <span class='highlight text-gradient'>work</span>", 'process_subtitle': 'Four clear steps from first contact to project start.',
 'process_1_title': 'Enquiry', 'process_1_text': 'You leave your business name, your name and email. It takes under a minute.',
 'process_2_title': 'Short brief', 'process_2_text': 'You get an email with a link to a ~3-minute brief — goals, audience, budget and deadline.',
 'process_3_title': 'Offer within 24 hours', 'process_3_text': 'We come back with a concrete proposal that fits your goals and budget.',
 'process_4_title': 'Kick-off and transparent reporting', 'process_4_text': 'We start with a clear plan and regular feedback based on real data.',
 'contact_form_privacy': "By submitting the form you agree to our <a href='privacy-policy.html'>Privacy Policy</a>.", 'footer_cookies': 'Cookie settings'}
for idx, (vals, new) in enumerate([(BG, NEW_BG), (EN, NEW_EN)]):
    b = blocks[idx]
    for k, v in vals.items():
        b, n = re.subn(r'(^\s+' + k + r':\s*)"(?:[^"\\]|\\.)*"', lambda m: m.group(1) + json.dumps(v, ensure_ascii=False), b, count=1, flags=re.M)
        assert n == 1, (idx, k)
    add = ''.join(f'        {k}: {json.dumps(v, ensure_ascii=False)},{nl}' for k, v in new.items())
    b, n = re.subn(r'(^\s+hero_cta_secondary:.*?\r?\n)', lambda m: m.group(1) + add, b, count=1, flags=re.M)
    assert n == 1
    blocks[idx] = b
open('js/translations.js', 'w', encoding='utf-8', newline='').write(''.join(blocks))

# ---------------- thank-you / brief: no PII in URLs, events via consent layer ----------------
s = rd('thank-you.html')
s = re.sub(r"if \(en\) q\.set\('lang', 'en'\);\s*document\.getElementById\('t-brief'\)\.href = 'brief\.html\?' \+ q\.toString\(\);",
           "document.getElementById('t-brief').href = 'brief.html' + (en ? '?lang=en' : '');", s)
s = s.replace("var q = new URLSearchParams();\n            if (info.name) q.set('name', info.name);\n            if (info.email) q.set('email', info.email);\n            if (info.company) q.set('company', info.company);\n", "try { sessionStorage.setItem('mdPrefill', JSON.stringify(info)); } catch (e) {}\n")
s = s.replace("typeof window.fbq === 'function') {\n                    window.fbq('track', 'Lead');", "typeof window.mdTrack === 'function') {\n                    window.mdTrack('generate_lead', { form_id: 'contactForm', page: location.pathname });")
wr('thank-you.html', s)
s = rd('brief.html')
s = s.replace("if (params.get('name')) f.elements.name.value = params.get('name').slice(0, 120);", "var pf = {}; try { pf = JSON.parse(sessionStorage.getItem('mdPrefill') || '{}'); } catch (e) {}\n            if (pf.name) f.elements.name.value = String(pf.name).slice(0, 120);")
s = s.replace("if (params.get('email')) f.elements.email.value = params.get('email').slice(0, 200);", "if (pf.email) f.elements.email.value = String(pf.email).slice(0, 200);")
s = s.replace("if (params.get('company')) f.elements.company.value = params.get('company').slice(0, 160);", "if (pf.company) f.elements.company.value = String(pf.company).slice(0, 160);")
wr('brief.html', s)

# ---------------- lead-form.js: attribution + event ----------------
L = open('js/lead-form.js', encoding='utf-8').read()
L = L.replace("const body = Object.assign({ lang: lang() }, payload);", "const body = Object.assign({ lang: lang(), attribution: (window.mdAttribution ? window.mdAttribution() : {}) }, payload);")
L = L.replace("if (typeof window.fbq === 'function') window.fbq('trackCustom', 'BriefSubmitted');", "if (typeof window.mdTrack === 'function') window.mdTrack('brief_submitted', { page: location.pathname });")
open('js/lead-form.js', 'w', encoding='utf-8', newline='').write(L)

# ---------------- submit-lead.js: keep attribution without requiring DB migration ----------------
F = open('netlify/functions/submit-lead.js', encoding='utf-8').read()
F = F.replace("message: `Бизнес: ${lead.company}`,", "message: `Бизнес: ${lead.company}` + attribLine(body.attribution),")
F = F.replace("exports.handler = async (event) => {", """function attribLine(a) {
    if (!a || typeof a !== 'object') return '';
    const keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'referrer', 'landing', 'page_url'];
    const parts = keys.filter((k) => a[k]).map((k) => `${k}=${String(a[k]).replace(/[\\r\\n]+/g, ' ').slice(0, 120)}`);
    return parts.length ? ` | ${parts.join('; ')}` : '';
}

exports.handler = async (event) => {""", 1)
open('netlify/functions/submit-lead.js', 'w', encoding='utf-8', newline='').write(F)

# ---------------- CSS ----------------
C = open('css/styles.css', encoding='utf-8').read()
C += '''

/* ===== v15 additions: process, form privacy, footer legal ===== */
.process-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:20px;margin-top:40px;text-align:left}
.process-step{position:relative;padding:28px 24px;border-radius:16px;background:var(--card-bg,rgba(255,255,255,.04));border:1px solid rgba(255,255,255,.1)}
.process-step h3{margin:14px 0 8px;font-size:1.1rem}
.process-step p{margin:0;color:var(--text-secondary,#B3B3B3);line-height:1.6}
.step-num{display:inline-flex;width:36px;height:36px;border-radius:50%;align-items:center;justify-content:center;font-weight:700;background:#CC361E;color:#fff}
.form-privacy{margin:12px 0 0;font-size:.8rem;line-height:1.5;color:var(--text-secondary,#B3B3B3)}
.form-privacy a,.footer-legal a{color:inherit;text-decoration:underline}
.footer-legal{margin:6px 0 0;font-size:.8rem;opacity:.75;text-align:center}
@media (prefers-reduced-motion:reduce){*{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}
'''
open('css/styles.css', 'w', encoding='utf-8', newline='').write(C)
print('done')
