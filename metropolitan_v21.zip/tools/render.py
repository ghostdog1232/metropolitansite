#!/usr/bin/env python3
"""Вмъква partials/header.html и partials/footer.html във всички страници с пълна навигация.
Пуснете след всяка промяна на partials/: python3 tools/render.py"""
import re,glob,os
os.chdir(os.path.join(os.path.dirname(__file__),'..'))
H=open('partials/header.html',encoding='utf-8').read().strip()
F=open('partials/footer.html',encoding='utf-8').read().strip()
n=0
for f in glob.glob('*.html'):
    s=open(f,encoding='utf-8').read(); o=s
    if f in('thank-you.html','brief.html','admin.html','404.html'): continue
    if '<!--NAV:START-->' in s:
        s=re.sub(r'<!--NAV:START-->.*?<!--NAV:END-->','<!--NAV:START-->'+H+'<!--NAV:END-->',s,flags=re.S)
    else:
        m=re.search(r'<nav class="(navbar[^"]*)"',s)
        if not m and re.search(r'<nav id="navbar"',s):
            s=re.sub(r'<nav id="navbar"[^>]*>.*?</nav>',lambda mm:'<!--NAV:START-->'+H.replace('<nav class="navbar"','<nav class="navbar scrolled"',1)+'<!--NAV:END-->',s,count=1,flags=re.S)
        if m: s=re.sub(r'<nav class="navbar[^"]*".*?</nav>',lambda mm:'<!--NAV:START-->'+H.replace('<nav class="navbar"','<nav class="'+m.group(1)+'"',1)+'<!--NAV:END-->',s,count=1,flags=re.S)
    if '<!--FOOTER:START-->' in s:
        s=re.sub(r'<!--FOOTER:START-->.*?<!--FOOTER:END-->','<!--FOOTER:START-->'+F+'<!--FOOTER:END-->',s,flags=re.S)
    else:
        s=re.sub(r'<footer.*?</footer>',lambda m:'<!--FOOTER:START-->'+F+'<!--FOOTER:END-->',s,count=1,flags=re.S)
    s=s.replace('Metropolitan Agency','Metropolitan Digital')
    if s!=o: open(f,'w',encoding='utf-8',newline='').write(s); n+=1
print('rendered',n)
