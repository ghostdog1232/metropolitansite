#!/usr/bin/env python3
"""Фази 2–4: съдържание, страници и фунии. Пуска се еднократно върху v15 след phase1/render."""
import re, os, glob, json, html
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
BASE = 'https://metropolitandigital.bg'
rd = lambda f: open(f, encoding='utf-8').read()
def wr(f, s): open(f, 'w', encoding='utf-8', newline='').write(s)
TODO = lambda t: f'<mark class="todo">[ПОПЪЛНИ: {t}]</mark>'
def sec(id_, inner, cls='section-padding'): return f'<section class="{cls}" id="{id_}"><div class="container">{inner}</div></section>\n'
FOOT = '<!--FOOTER:START-->'

def insert_before_footer(f, block, marker_id):
    s = rd(f)
    if f'id="{marker_id}"' in s: return
    s = s.replace(FOOT, block + FOOT, 1); wr(f, s)

# ---------- 0) config.js + funnels.js everywhere ----------
for f in glob.glob('*.html'):
    s = rd(f)
    if '/js/config.js' not in s and 'js/consent.js' in s:
        s = re.sub(r'<script src="/?js/consent\.js"></script>', '<script src="/js/config.js"></script>\n    <script src="/js/consent.js"></script>', s, count=1)
    if '/js/funnels.js' not in s and 'lead-form.js' in s and f not in ('brief.html', 'thank-you.html', 'admin.html'):
        s = re.sub(r'(<script src="/?js/lead-form\.js"></script>)', r'\1\n    <script src="/js/funnels.js"></script>', s, count=1)
    wr(f, s)
# funnels.js: fill data-price from config
fj = rd('js/funnels.js')
if 'data-price' not in fj:
    fj = fj.replace("    var CFG = window.MD_CONFIG || {};", """    var CFG = window.MD_CONFIG || {};
    document.querySelectorAll('[data-price]').forEach(function (el) {
        var v = (CFG.PRICING || {})[el.getAttribute('data-price')];
        if (v) { el.textContent = 'от ' + v + ' €' + (el.getAttribute('data-per') || ''); el.classList.remove('todo'); }
    });""", 1); wr('js/funnels.js', fj)

PRICE = lambda key, per='': f'<span class="todo" data-price="{key}" data-per="{per}">[ПОПЪЛНИ: от X €{per}]</span>'

# ---------- 1) Funnel blocks ----------
HP = '<input type="text" name="website_url" tabindex="-1" autocomplete="off" aria-hidden="true" style="display:none">'
CONSENT = '<p class="funnel-note">Изпращайки формата, се съгласявате с <a href="/privacy-policy">Политиката за поверителност</a>.</p>'
AUDIT = sec('audit', f'''<div class="funnel-box"><span class="hero-badge">Безплатно</span>
<h2>Безплатен 48-часов видео одит</h2>
<p>Получете безплатен 5-минутен персонален Loom видео анализ на вашия сайт или рекламен акаунт до 48 часа.</p>
<form class="funnel-form" data-funnel="audit">
<label for="au-url">URL на сайта</label><input id="au-url" type="text" inputmode="url" data-detail="site_url" required maxlength="160" placeholder="www.vashsait.bg">
<label for="au-email">Бизнес имейл</label><input id="au-email" type="email" name="email" required autocomplete="email" maxlength="200" placeholder="name@company.bg">
<label for="au-budget">Текущ или планиран месечен рекламен бюджет</label>
<select id="au-budget" data-detail="monthly_budget" required><option value="">Изберете…</option><option>под 1000 €</option><option>1000–3000 €</option><option>над 3000 €</option></select>
{HP}<button type="submit" class="btn-primary btn-large" data-cta="audit_submit">Искам безплатния одит</button>
<p class="funnel-note">След изпращане можете веднага да запазите 15-минутна среща за разбор на видеото.</p>{CONSENT}</form></div>''')
MAGNET = lambda: sec('lead-magnet', f'''<div class="funnel-box"><span class="hero-badge">Безплатен PDF чеклист</span>
<h2>15 сценария за конвертиращи Reels и TikTok видеа за бизнес</h2>
<p>Готови идеи за кратки видеа, които водят до запитвания, а не само до гледания. Оставете имейл и ще го получите веднага.</p>
<form class="funnel-form" data-funnel="lead_magnet"><label for="lm-email">Имейл</label>
<input id="lm-email" type="email" name="email" required autocomplete="email" maxlength="200" placeholder="name@company.bg">{HP}
<button type="submit" class="btn-primary" data-cta="lead_magnet_submit">Изпратете ми чеклиста</button>{CONSENT}</form></div>''')
CONFIG = sec('configurator-section', '''<div class="section-header"><h2>Кой пакет е подходящ за вас?</h2><p>Четири кратки въпроса — получавате препоръка и персонална оферта по имейл.</p></div><div class="funnel-box" id="md-configurator" aria-live="polite"><noscript>Включете JavaScript или ни пишете на office@metropolitandigital.bg.</noscript></div>''', 'section-padding container-center')

DAYS = ['Старт: уточняваме целите, аудиторията и събираме материалите (лого, текстове, снимки).',
        'Структура на сайта и wireframe на ключовите страници за одобрение.',
        'Дизайн на началната и ключовите страници, съобразен с бранда ви.',
        'Разработка: адаптивен, бърз сайт с формуляри и проследяване на събитията.',
        'Съдържание, SEO основа (мета данни, структура, схеми) и свързване на формите.',
        'Тестове на мобилни и десктоп, скорост и формуляри; финални корекции.',
        'Пускане онлайн и предаване: достъпи, кратко обучение и план за следващите стъпки.']
DAYS_HTML = '<ol class="day-list">' + ''.join(f'<li>{d}</li>' for d in DAYS) + '</ol><p class="funnel-note">Срокът тече от момента, в който получим необходимите материали и одобрения.</p>'
TRIPWIRE = sec('site-7-days', f'''<h2>Сайт до 7 дни — график по дни</h2>{DAYS_HTML}
<div class="price-table"><div class="price-card"><h3>Експресен сайт (7 дни)</h3><p class="price">{PRICE('express_from')}</p><p class="funnel-note">Цена без ДДС. Фиксиран стартов пакет, обхватът се описва в офертата.</p>
<ul><li>Адаптивен сайт, SEO основа</li><li>Формуляри и проследяване на събитията</li><li>Предаване на Ден 7</li></ul>
<a href="/#contact" class="btn-primary" data-cta="express_quote">Получи оферта</a></div></div>''')
DAY7 = sec('day-7-next', '''<div class="funnel-box"><span class="hero-badge">Ден 7 и после</span><h2>Сайтът е онлайн. Какво следва?</h2>
<p>Един нов сайт сам по себе си не води клиенти: нужен му е постоянен трафик и измерване на конверсиите. На Ден 7 ви предаваме сайта и ви показваме план за следващите стъпки в месечния Пълен Дигитален Пакет: реклама в Google и Meta, SEO/GEO и кратки видеа, управлявани заедно и с единни отчети.</p>
<p><a class="btn-primary" href="/service-bundle#configurator-section" data-cta="day7_bundle">Вижте пакета и конфигуратора</a></p></div>''')
RHYTHM = '''<h2>Работен ритъм и отчетност</h2><ul class="day-list" style="counter-reset:none"><style>.rhythm li::before{content:"✓"!important}</style></ul>
<ul class="day-list rhythm"><li>Седмични спринтове: ясни задачи и приоритети за всяка седмица.</li><li>Достъп до табло с данни: показателите са видими за вас, когато са ви нужни.</li><li>Ясни KPI, договорени преди старта (напр. запитвания, цена на запитване, органичен трафик).</li><li>Месечен отчет с изводи и следващи стъпки; кратък седмичен преглед по договорка.</li></ul>'''
BUNDLE_BLOCK = sec('pricing', f'''<h2>Цени и бюджети</h2>
<div class="price-table"><div class="price-card"><h3>Такса за управление</h3><p class="price">{PRICE('bundle_from','/мес.')}</p><p class="funnel-note">Без ДДС. Плаща се към агенцията.</p><ul><li>Стратегия и управление на кампаниите</li><li>SEO/GEO оптимизация</li><li>Кратки видеа и съдържание</li><li>Отчети и седмичен ритъм</li></ul></div>
<div class="price-card"><h3>Рекламен бюджет</h3><p class="price">{PRICE('min_ad_budget','/мес.')}</p><p class="funnel-note">Препоръчителен минимум. Плаща се директно към Google/Meta и е отделен от таксата за управление.</p><ul><li>Вие контролирате и виждате разходите</li><li>Бюджетът се определя според целите</li></ul></div></div>
<p>Така знаете цялата месечна инвестиция още преди запитването: такса за управление + рекламен бюджет към платформите.</p>{RHYTHM}''')

GEO = sec('geo-aeo', '''<h2>GEO / AEO: видимост в AI търсачките</h2>
<p>Все повече хора получават отговори директно от ChatGPT, Perplexity и Google AI Overviews, без да кликват върху класическа страница. GEO (Generative Engine Optimization) и AEO (Answer Engine Optimization) са оптимизация на съдържанието ви така, че да бъде разбирано, цитирано и препоръчвано в тези отговори.</p>
<ul class="day-list rhythm"><li><strong>Ясни отговори:</strong> кратки, цитируеми отговори на реалните въпроси на клиентите ви.</li><li><strong>Структурирани данни:</strong> Schema.org за организация, услуги и често задавани въпроси.</li><li><strong>Последователна идентичност:</strong> еднакви име, контакти и профили в сайта, Google Business Profile и каталозите.</li><li><strong>Достоверност:</strong> данни, източници и авторство, които AI системите разпознават като надеждни.</li><li><strong>Технически достъп:</strong> скорост, чиста структура и правилни настройки за ботовете.</li><li><strong>Мониторинг:</strong> периодична проверка как марката ви се появява в AI отговорите по ключови заявки.</li></ul>
<p class="funnel-note">AI системите са променливи и не могат да се контролират напълно, затова не обещаваме конкретни позиции или цитирания: работим върху факторите, които зависят от нас, и ги измерваме.</p>''')

# ---------- 2) Insert funnel blocks into pages ----------
for f in ('service-seo.html', 'service-ads.html'): insert_before_footer(f, AUDIT, 'audit')
for f in ('blog-kratki-videa-konversii.html', 'blog-marketingov-plan-byudzhet.html', 'blog-sait-za-pod-10-dni.html', 'blog-seo-dalgosrochna-investitsia.html', 'service-video.html', 'service-social.html'): insert_before_footer(f, MAGNET(), 'lead-magnet')
insert_before_footer('service-seo.html', GEO, 'geo-aeo')
insert_before_footer('service-web.html', TRIPWIRE + DAY7, 'site-7-days')
insert_before_footer('service-express.html', TRIPWIRE + DAY7, 'site-7-days')
insert_before_footer('service-bundle.html', BUNDLE_BLOCK + CONFIG, 'pricing')
# index: configurator before contact
s = rd('index.html')
if 'configurator-section' not in s: s = s.replace('<!-- Contact Section -->', CONFIG + '<!-- Contact Section -->', 1)
wr('index.html', s)

# ---------- 3) 7-day wording ----------
for f in ('service-web.html', 'js/translations.js'):
    s = rd(f).replace('Само до 1 седмица!', 'Само до 7 дни!').replace('до 1 седмица', 'до 7 дни'); wr(f, s)
b = rd('blog-sait-za-pod-10-dni.html')
b = b.replace('под 10 дни', 'до 7 дни').replace('Под 10 дни', 'До 7 дни').replace('за по-малко от 10 дни', 'до 7 дни').replace('Сайт за до 7 дни', 'Сайт до 7 дни')
wr('blog-sait-za-pod-10-dni.html', b)
bl = rd('blog.html').replace('Сайт за под 10 дни', 'Сайт до 7 дни'); wr('blog.html', bl)
os.rename('blog-sait-za-pod-10-dni.html', 'blog-sait-za-7-dni.html')
for f in glob.glob('*.html') + ['sitemap.xml', 'netlify.toml', 'js/translations.js']:
    s = rd(f)
    if 'pod-10-dni' in s: wr(f, s.replace('blog-sait-za-pod-10-dni', 'blog-sait-za-7-dni'))
t = rd('netlify.toml')
t = t.replace('[[redirects]]\n  from = "/index.html"', '[[redirects]]\n  from = "/blog-sait-za-pod-10-dni*"\n  to = "/blog-sait-za-7-dni"\n  status = 301\n  force = true\n\n[[redirects]]\n  from = "/index.html"', 1)
wr('netlify.toml', t)

# ---------- 4) page maker ----------
donor = rd('service-pr.html')
head_donor = donor[:donor.index('<body')]
tail_donor = donor[donor.index('<!--FOOTER:END-->') + len('<!--FOOTER:END-->'):]
def make_page(fname, title, desc, body, ld=None, robots=None):
    h = head_donor
    h = re.sub(r'<title>.*?</title>', f'<title>{html.escape(title)}</title>', h, flags=re.S)
    h = re.sub(r'<meta name="description" content=".*?">', f'<meta name="description" content="{html.escape(desc, quote=True)}">', h)
    url = f'{BASE}/{fname[:-5]}'
    h = re.sub(r'<link rel="canonical" href=".*?">', f'<link rel="canonical" href="{url}">', h)
    h = re.sub(r'(<meta property="og:url" content=")[^"]*', r'\g<1>' + url, h)
    h = re.sub(r'(<meta (?:property|name)="(?:og|twitter):title" content=")[^"]*', r'\g<1>' + html.escape(title, quote=True), h)
    h = re.sub(r'(<meta (?:property|name)="(?:og|twitter):description" content=")[^"]*', r'\g<1>' + html.escape(desc, quote=True), h)
    h = re.sub(r'<script type="application/ld\+json">.*?</script>\s*', '', h, flags=re.S)
    extra = ''.join('<script type="application/ld+json">' + json.dumps(x, ensure_ascii=False) + '</script>\n' for x in (ld or []))
    if robots: extra += f'<meta name="robots" content="{robots}">\n'
    h = h.replace('</head>', extra + '</head>')
    wr(fname, h + '<body>\n<!--NAV:START--><nav class="navbar scrolled" id="navbar"></nav><!--NAV:END-->\n' + body + '\n<!--FOOTER:START--><footer></footer><!--FOOTER:END-->' + tail_donor)
bc = lambda *items: {"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": n, "item": u} for i, (n, u) in enumerate(items)]}
HERO = lambda badge, h1, lead: f'<section class="service-detail-hero"><div class="hero-bg"><div class="gradient-sphere sphere-1"></div><div class="gradient-sphere sphere-2"></div></div><div class="container service-detail-content"><div class="hero-badge">{badge}</div><h1>{h1}</h1><p class="lead">{lead}</p></div></section>'

# ---------- 5) About / Team ----------
team = [('Технически SEO анализатори', 'SEO одити, технически оптимизации, GEO/AEO'), ('PPC стратези', 'Кампании в Google и Meta, измерване и оптимизация'), ('Уеб разработчици', 'Бързи, адаптивни и SEO-готови сайтове'), ('Криейтив специалисти', 'Брандинг, визуална идентичност и дизайн'), ('Видео специалисти', 'Кратки видеа, монтаж и съдържание за социални мрежи')]
cards = ''.join(f'<div class="team-card"><div class="team-photo">{TODO("снимка")}</div><h3>{TODO("Име Фамилия")}</h3><p><strong>{r}</strong></p><p>{d}</p><p>Опит: {TODO("години и предишни компании/проекти")}</p><p><a href="#">LinkedIn: {TODO("URL")}</a></p></div>' for r, d in team)
about_body = HERO('За нас', 'Дигитална агенция в София, България', 'Metropolitan Digital стартира през 2026 г., но зад агенцията стоят специалисти с натрупан индивидуален опит в SEO, реклама, уеб разработка, дизайн и видео. Работим с прозрачни цели, ясна комуникация и измерими резултати.') + \
  sec('team', f'''<h2>Екипът зад агенцията</h2><p>Всеки специалист води собствената си област и носи опит от предишни проекти и работодатели. Така получавате експертиза на ниво специалист, а не универсален генералист.</p><div class="team-grid">{cards}</div>
<h2>Как работим</h2><p>Преди всеки проект уточняваме целите и бюджета, договаряме KPI и отчитаме резултатите редовно. Без скрити такси и без празни обещания.</p>
<p><strong>Юридическо лице:</strong> Метрополитан ООД, ЕИК 207499878, София, България. Адрес за кореспонденция: {TODO("адрес")}.</p>
<h2>Доверие и профили</h2><p>Google Business Profile: {TODO("линк")} · Clutch: {TODO("линк")}</p>
<p><a class="btn-primary" href="/#contact" data-cta="about_quote">Получи оферта</a> <a class="btn-secondary" href="/service-seo#audit" data-cta="about_audit">Безплатен видео одит</a></p>''', 'service-body section-padding')
make_page('about.html', 'За нас и екип | Metropolitan Digital', 'Запознайте се с екипа на Metropolitan Digital, дигитална агенция в София, България: SEO, PPC, уеб, дизайн и видео специалисти с реален опит. Свържете се с нас.', about_body,
          [bc(('Начало', BASE + '/'), ('За нас', BASE + '/about'))])

# ---------- 6) Portfolio: static projects ----------
P = [('techstart', 'TechStart BG', 'Технологична компания', 'images/techstart-cover.png', 'Брандинг и уеб присъствие'),
     ('greenlife', 'GreenLife', 'Еко и здравословен начин на живот', 'images/greenlife-cover.png', 'Брандинг и социални мрежи'),
     ('urbanshop', 'UrbanShop', 'Онлайн магазин (e-commerce)', 'images/urbanshop-cover.png', 'Онлайн магазин и реклама'),
     ('hoodwear', 'Hood Wear Ltd.', 'Streetwear облекло', 'images/hoodwear/hood-cover-final.jpg', 'Брандинг, brandbook и e-commerce присъствие')]
for slug, name, niche, img, svc in P:
    extra = '<p>Изграждане на бранд идентичност, маркетинг стратегия и e-commerce присъствие за streetwear бранд, включително brandbook и графични материали.</p>' if slug == 'hoodwear' else f'<p>{TODO("опишете какво е направено")}</p>'
    body = HERO('Проект · ' + niche, name + ': ' + svc, f'Тип: {TODO("клиентски проект / пилотна разработка / дизайн концепция")}') + sec('case', f'''<img src="/{img}" alt="{html.escape(name)} — {html.escape(svc)}" style="max-width:100%;border-radius:16px;margin-bottom:24px" loading="lazy">
<div class="case-sec"><h2>Клиент / ниша</h2><p>{name} — {niche}.</p></div>
<div class="case-sec"><h2>Проблем</h2><p>{TODO("пред какво предизвикателство е бил клиентът")}</p></div>
<div class="case-sec"><h2>Решение</h2><p><strong>Услуги:</strong> {svc}. <strong>Технологии:</strong> {TODO("платформи/инструменти")}</p>{extra}</div>
<div class="case-sec"><h2>Измерим резултат</h2><p>{TODO("конкретни, проверими числа и период; ако проектът е концепция, напишете „Концепция — без измерени резултати“")}</p></div>
<p><a class="btn-primary" href="/#contact" data-cta="project_quote">Искам подобен резултат</a> <a class="btn-secondary" href="/portfolio">Всички проекти</a></p>''', 'service-body section-padding')
    make_page(f'project-{slug}.html', f'{name}: {svc} | Metropolitan Digital', f'Проект на Metropolitan Digital, дигитална агенция в България: {name} ({niche}). Клиент, проблем, решение и измерим резултат. Заявете оферта за вашия бизнес.', body,
              [bc(('Начало', BASE + '/'), ('Проекти', BASE + '/portfolio'), (name, f'{BASE}/project-{slug}'))])
cards = ''.join(f'<a class="proj-card" href="/project-{s}"><img src="/{i}" alt="{html.escape(n)} — {html.escape(v)}" loading="lazy" width="800" height="600"><div><span>{nich}</span><h3>{n}</h3><p>{v}</p></div></a>' for s, n, nich, i, v in P)
GRID = f'<div class="proj-grid">{cards}</div>'
s = rd('index.html')
s = re.sub(r'<div class="work-grid">.*?</div>\s*<div style="margin-top: 50px', GRID + '\n            <div style="margin-top: 50px', s, count=1, flags=re.S)
s = s.replace('Зареждане на проекти...', '')
wr('index.html', s)
s = rd('portfolio.html')
s = re.sub(r'<div class="work-grid" id="all-portfolio-grid">.*?</div>(?=\s*</div>\s*</section>)', GRID, s, count=1, flags=re.S)
s = s.replace('Зареждане на проекти...', '')
wr('portfolio.html', s)

# ---------- 7) services.html static ----------
SV = [('service-seo', 'SEO оптимизация и GEO/AEO', 'Видимост в Google и в AI търсачките.'), ('service-ads', 'Реклама в Google и Meta', 'Кампании с измерими цели и прозрачни отчети.'), ('service-social', 'Социални мрежи', 'Стратегия, съдържание и общност.'), ('service-marketing', 'Маркетинг план', 'Цели, канали, бюджет и KPI.'), ('service-video', 'Видео обработка', 'Кратки видеа и монтаж за реклама и социални мрежи.'), ('service-branding', 'Брандинг и графичен дизайн', 'Идентичност, която ви отличава.'), ('service-pr', 'PR и комуникации', 'Имидж и медийно присъствие.'), ('service-web', 'Изработване на сайтове', 'Сайт до 7 дни с ясен график.'), ('service-express', 'Маркетинг Експрес', 'Бърз старт с фиксиран обхват.'), ('service-bundle', 'Пълен Дигитален Пакет', 'Месечен абонамент за няколко канала.')]
sc = ''.join(f'<a class="proj-card" href="/{u}"><div><h3>{t}</h3><p>{d}</p></div></a>' for u, t, d in SV)
s = rd('services.html')
s2 = re.sub(r'<div[^>]*id="all-services-grid"[^>]*>.*?</div>(?=\s*</div>\s*</section>)', f'<div class="proj-grid">{sc}</div>', s, count=1, flags=re.S)
if s2 == s: print('WARN services grid not replaced')
wr('services.html', s2.replace('Зареждане...', ''))

# ---------- 8) thank-you with Calendly ----------
ty = rd('thank-you.html')
if 'calendly-box' not in ty:
    ty = ty.replace('</main>', '''<div class="container" style="text-align:center;margin-top:24px"><div id="calendly-box"><h2 style="font-size:1.4rem">Искате отговор още днес?</h2><p>Запазете 15-минутна среща — най-горещите запитвания обработваме първи.</p><div id="calendly-embed" style="min-width:300px;height:700px"></div><p id="calendly-fallback" hidden>Календарът ще бъде добавен скоро. Обадете се на <a href="tel:+359896496164">+359 896 496 164</a> или пишете на <a href="mailto:office@metropolitandigital.bg">office@metropolitandigital.bg</a>.</p></div></div>
    <script>
    (function(){var u=(window.MD_CONFIG||{}).CALENDLY_URL, e=document.getElementById('calendly-embed');
    var f=new URLSearchParams(location.search).get('f');
    if(f==='lead_magnet'){var b=document.getElementById('calendly-box');var h=b.querySelector('h2');h.textContent='Чеклистът е на път към пощата ви';b.querySelector('p').textContent='Проверете и папка „Промоции“/„Спам“. Ако искате да обсъдим видео стратегия за бизнеса ви, запазете кратка среща.';}
    if(!u){e.hidden=true;document.getElementById('calendly-fallback').hidden=false;return;}
    var s=document.createElement('script');s.src='https://assets.calendly.com/assets/external/widget.js';s.async=true;
    s.onload=function(){window.Calendly&&window.Calendly.initInlineWidget({url:u+(u.indexOf('?')>-1?'&':'?')+'hide_gdpr_banner=1',parentElement:e});};document.body.appendChild(s);})();
    </script>
    </main>''', 1)
    wr('thank-you.html', ty)

# ---------- 9) sitemap + schema for new pages ----------
sm = rd('sitemap.xml')
add = ''.join(f'  <url><loc>{BASE}/{p}</loc><lastmod>2026-11-14</lastmod><priority>0.{pr}</priority></url>\n' for p, pr in [('about', 7)] + [(f'project-{x[0]}', 6) for x in P])
sm = sm.replace('</urlset>', add + '</urlset>') if '/about<' not in sm else sm
sm = sm.replace('blog-sait-za-pod-10-dni', 'blog-sait-za-7-dni')
wr('sitemap.xml', sm)
print('content ok')
