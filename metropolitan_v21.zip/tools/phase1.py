import re, glob, os
os.chdir(os.path.join(os.path.dirname(__file__), '..'))
rd=lambda f:open(f,encoding='utf-8').read()
def wr(f,s): open(f,'w',encoding='utf-8',newline='').write(s)
PAGES=['index','services','portfolio','portfolio-details','service-details','blog','brief','thank-you','privacy-policy','terms','admin','404']+[os.path.basename(f)[:-5] for f in glob.glob('service-*.html')+glob.glob('blog-*.html')]
PAGES=sorted(set(PAGES),key=len,reverse=True)
alt='|'.join(re.escape(p) for p in PAGES if p!='index')
PHONE='<a href="tel:+359896496164" class="nav-phone" data-cta="nav_phone" aria-label="Обадете се: +359 896 496 164"><i class="fa-solid fa-phone"></i><span class="nav-phone-num"> +359 896 496 164</span></a>\n                '
for f in glob.glob('*.html'):
    s=rd(f)
    s=s.replace('????? ?????','Пълен пакет')
    s=s.replace('metropolitandigitall@gmail.com','office@metropolitandigital.bg')
    # header phone + hide EN toggle until a real EN version exists
    if 'id="lang-toggle"' in s and 'nav-phone' not in s:
        s=s.replace('<a href="#" id="lang-toggle" class="btn-secondary">','%s<a href="#" id="lang-toggle" class="btn-secondary" hidden style="display:none" aria-hidden="true" tabindex="-1">'%PHONE)
    # footer logo must not be an h2
    s=re.sub(r'<h2>(\s*<img src="images/footer_logo\.png"[^>]*>\s*)</h2>',r'<div class="footer-logo">\1</div>',s)
    # honeypot: really hidden
    s=s.replace('<div class="hp-field" aria-hidden="true">','<div class="hp-field" aria-hidden="true" style="display:none">')
    # leftover template placeholders in the project modal
    s=re.sub(r'<span id="modalCategory" data-t="category">[^<]*</span>','<span id="modalCategory"></span>',s)
    s=re.sub(r'<h3 id="modalTitle" data-t="title">[^<]*</h3>','<h3 id="modalTitle"></h3>',s)
    s=re.sub(r'<p id="modalDescription" data-t="description">[^<]*</p>','<p id="modalDescription"></p>',s)
    if f=='brief.html': s=s.replace('<h1 id="t-done-title">','<h2 id="t-done-title">').replace('Благодарим ви!</h1>','Благодарим ви!</h2>',1)
    wr(f,s)
# quote modal: hidden honeypot + phone
q=rd('js/quote-modal.js').replace('<div class="hp-field" aria-hidden="true">','<div class="hp-field" aria-hidden="true" style="display:none">')
wr('js/quote-modal.js',q)
for f in ['netlify/functions/submit-lead.js','SETUP-LEADS.md']:
    wr(f,rd(f).replace('metropolitandigitall@gmail.com','office@metropolitandigital.bg'))
# EN toggle off: always Bulgarian
sc=rd('js/script.js'); sc=sc.replace("window.currentLang = localStorage.getItem('preferredLang') || 'bg';","window.currentLang = 'bg'; /* EN временно изключен до готова английска версия */"); wr('js/script.js',sc)
# JSON-LD address
i=rd('index.html'); i=i.replace('"identifier": "207499878",','"identifier": "207499878", "address": {"@type": "PostalAddress", "addressLocality": "София", "addressCountry": "BG"},'); wr('index.html',i)
# ---- clean URLs everywhere (.html removed) ----
rx_index=re.compile(r'(?<![\w.-])/?index\.html')
rx=re.compile(r'(?<![\w.-])(%s)\.html'%alt)
targets=glob.glob('*.html')+glob.glob('js/*.js')+['netlify/functions/submit-lead.js','sitemap.xml']
for f in targets:
    s=rd(f); o=s
    s=rx_index.sub('/',s); s=rx.sub(r'\1',s)
    # absolute-root fix: bare relative 'service-x' links resolve from root already; make them root-absolute inside href/src-less nav
    s=re.sub(r'href="((?:%s))(["?#])'%alt,r'href="/\1\2',s)
    if s!=o: wr(f,s)
# sitemap homepage
sm=rd('sitemap.xml').replace('https://metropolitandigital.bg//','https://metropolitandigital.bg/'); wr('sitemap.xml',sm)
# netlify redirects/rewrites + robots
t=rd('netlify.toml')
t=t.replace('''[[redirects]]
  from = "/index.html"
  to = "/"
  status = 301
''','')
t=t.replace('for = "/admin.html"','for = "/admin*"')
rules='''[[redirects]]
  from = "/index.html"
  to = "/"
  status = 301
  force = true
'''
for p in PAGES:
    if p in('index','404'): continue
    rules+=f'\n[[redirects]]\n  from = "/{p}.html"\n  to = "/{p}"\n  status = 301\n  force = true\n\n[[redirects]]\n  from = "/{p}"\n  to = "/{p}.html"\n  status = 200\n'
wr('netlify.toml',t+'\n# Clean URLs: .html -> 301, clean path -> internal rewrite\n'+rules+'\n[[redirects]]\n  from = "/*"\n  to = "/404.html"\n  status = 404\n')
r=rd('robots.txt').replace('Disallow: /admin.html','Disallow: /admin'); wr('robots.txt',r)
# CSS
c=rd('css/styles.css')+'''
.hp-field{display:none!important}
.footer-logo{margin:0 0 12px}
.nav-phone{display:inline-flex;align-items:center;gap:6px;font-weight:600;white-space:nowrap;color:inherit;text-decoration:none}
@media (min-width:992px) and (max-width:1320px){.nav-phone-num{display:none}}
#lang-toggle[hidden]{display:none!important}
'''
wr('css/styles.css',c)
print('ok',len(PAGES))
