-- Metropolitan Digital — Lead Generation Flow
-- Run once in Supabase -> SQL Editor. Safe to run again.

-- 1) Columns on the existing `leads` table
--    (the form now sends: business name, person name, email)
alter table public.leads add column if not exists company text;
alter table public.leads add column if not exists contact_preference text;
alter table public.leads add column if not exists lang text;
alter table public.leads add column if not exists source text;
alter table public.leads add column if not exists phone text;

-- older versions of this script added a CHECK on contact_preference; it is no longer needed
alter table public.leads drop constraint if exists leads_contact_preference_check;

-- 2) Allow the public website (anon key) to INSERT leads — nothing else.
alter table public.leads enable row level security;
drop policy if exists "anon can insert leads" on public.leads;
create policy "anon can insert leads" on public.leads
    for insert to anon with check (true);

-- 3) Table for the short brief (brief.html)
create table if not exists public.briefs (
    id          bigint generated always as identity primary key,
    created_at  timestamptz not null default now(),
    name        text not null,
    email       text not null,
    company     text,
    website     text,
    goals       text,
    audience    text,
    budget      text,
    deadline    text,
    notes       text
);

alter table public.briefs enable row level security;

drop policy if exists "anon can insert briefs" on public.briefs;
create policy "anon can insert briefs" on public.briefs
    for insert to anon with check (true);
