/**
 * Metropolitan Digital — Lead Generation Flow
 *
 * POST /.netlify/functions/submit-lead
 *   1. validates the inquiry
 *   2. saves it to Supabase (table `leads`: business name, person name, email)
 *   3. sends an internal notification with ALL form data to NOTIFY_EMAIL
 *   4. sends a branded auto-responder to the client
 *        - preference "email"   -> thanks + short brief link + offer within 24h
 *        - preference "meeting" -> thanks + booking link (Calendly / Google Meet)
 *
 * Email can be sent in two ways (the function picks automatically):
 *   A) Gmail / any SMTP account  – set SMTP_USER + SMTP_PASS (works without a company domain)
 *   B) Resend (https://resend.com) – set RESEND_API_KEY + FROM_EMAIL (needs a verified domain)
 *
 * Environment variables (Netlify -> Site configuration -> Environment variables):
 *   SMTP_USER             option A  – e.g. office@metropolitandigital.bg
 *   SMTP_PASS             option A  – Google "App password" (NOT the normal password)
 *   SMTP_HOST / SMTP_PORT optional  – default smtp.gmail.com / 465
 *   RESEND_API_KEY        option B  – API key from Resend
 *   FROM_EMAIL            option B  – e.g. "Metropolitan Digital <office@metropolitandigital.bg>"
 *   NOTIFY_EMAIL          optional  – internal inbox(es), comma separated (defaults to SMTP_USER)
 *   CALENDLY_URL          required for the "meeting" flow – booking link
 *   BRIEF_URL             optional  – defaults to https://metropolitandigital.bg/brief
 *   SITE_URL              optional  – defaults to https://metropolitandigital.bg
 *   SUPABASE_URL          optional  – defaults to the project URL used by the site
 *   SUPABASE_SERVICE_KEY  optional  – service role key; falls back to the public anon key
 */

const DEFAULT_SUPABASE_URL = 'https://cazcqxysmbtyseilckbg.supabase.co';
const DEFAULT_SUPABASE_ANON =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNhemNxeHlzbWJ0eXNlaWxja2JnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQyMDAwMDgsImV4cCI6MjA4OTc3NjAwOH0.-OOo_-KgiJU4GDWNDmY3F7iVq2tBxnxvSNwNwuJ9RzI';

const PREFERENCES = {
    email: {
        bg: 'Искам оферта по имейл (бърз бриф)',
        en: 'I want an offer by email (quick brief)'
    },
    meeting: {
        bg: 'Искам кратка среща / разговор за мащабен проект',
        en: 'I want a short meeting / call for a large project'
    }
};

const COLORS = { dark: '#122435', accent: '#224766', red: '#CC361E', bg: '#EFEFEF', text: '#1c2b3a', muted: '#6b7785' };

const json = (statusCode, body) => ({
    statusCode,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body)
});

const esc = (v) =>
    String(v ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);

// Single-line fields (names, subjects, emails): no line breaks allowed -> no header injection
const line = (v, max) => clean(v, max).replace(/\s+/g, ' ');

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[^\s@<>()[\]\\,;:"]{2,}$/;

/* ─────────────────────────── Email templates ─────────────────────────── */

function shell({ siteUrl, preheader, bodyHtml }) {
    return `<!doctype html>
<html lang="bg"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:${COLORS.bg};font-family:Arial,Helvetica,sans-serif;color:${COLORS.text};">
<span style="display:none;max-height:0;overflow:hidden;opacity:0;">${esc(preheader)}</span>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:${COLORS.bg};padding:24px 12px;">
<tr><td align="center">
  <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:14px;overflow:hidden;">
    <tr><td style="background:${COLORS.dark};padding:26px 32px;">
        <a href="${esc(siteUrl)}" style="text-decoration:none;"><img src="${esc(siteUrl)}/images/footer_logo.png" alt="Metropolitan Digital" height="40" style="display:block;height:40px;border:0;"></a>
    </td></tr>
    <tr><td style="height:4px;background:${COLORS.red};font-size:0;line-height:0;">&nbsp;</td></tr>
    <tr><td style="padding:32px;font-size:16px;line-height:1.6;">${bodyHtml}</td></tr>
    <tr><td style="background:${COLORS.dark};padding:20px 32px;font-size:12px;line-height:1.6;color:#aab6c3;">
        Metropolitan Digital &middot; <a href="${esc(siteUrl)}" style="color:#ffffff;text-decoration:none;">metropolitandigital.bg</a>
    </td></tr>
  </table>
</td></tr></table>
</body></html>`;
}

function button(href, label) {
    return `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0;"><tr><td style="background:${COLORS.red};border-radius:8px;">
        <a href="${esc(href)}" style="display:inline-block;padding:14px 28px;color:#ffffff;font-weight:bold;font-size:16px;text-decoration:none;">${esc(label)}</a>
    </td></tr></table>`;
}

const COPY = {
    bg: {
        subject: (n) => `Благодарим ви, ${n}! Получихме вашето запитване`,
        hi: (n) => `Здравейте, ${esc(n)},`,
        thanks: 'Благодарим ви, че се свързахте с <strong>Metropolitan Digital</strong>! Получихме вашето запитване и вече работим по него.',
        emailTitle: 'Следваща стъпка: кратък бриф',
        emailText: 'За да подготвим точна и персонализирана оферта, ви молим да попълните нашия кратък бриф. Отнема около 3 минути.',
        emailBtn: 'Попълни брифа',
        emailPromise: '<strong>Ще получите оферта до 24 часа</strong> след попълване на брифа.',
        meetingTitle: 'Следваща стъпка: запазете удобен час',
        meetingText: 'За мащабен проект най-добрият начин да започнем е кратък разговор. Изберете удобен за вас час от нашия календар:',
        meetingBtn: 'Запази час за среща',
        meetingFallback: 'Ще се свържем с вас в рамките на 24 часа, за да уточним удобен час за разговор.',
        summary: 'Вашето запитване',
        labels: { company: 'Бизнес', name: 'Име', email: 'Имейл' },
        signoff: 'Поздрави,<br><strong>Екипът на Metropolitan Digital</strong>',
        autoNote: 'Това е автоматично съобщение, но можете да отговорите директно на този имейл.',
        pre: 'Получихме вашето запитване – вижте следващата стъпка.'
    },
    en: {
        subject: (n) => `Thank you, ${n}! We received your inquiry`,
        hi: (n) => `Hello ${esc(n)},`,
        thanks: 'Thank you for contacting <strong>Metropolitan Digital</strong>! We have received your inquiry and are already working on it.',
        emailTitle: 'Next step: a quick brief',
        emailText: 'To prepare an accurate, tailored offer, please fill in our short brief. It takes about 3 minutes.',
        emailBtn: 'Fill in the brief',
        emailPromise: '<strong>You will receive an offer within 24 hours</strong> of completing the brief.',
        meetingTitle: 'Next step: book a convenient time',
        meetingText: 'For a large project, the best way to start is a short call. Pick a time that suits you from our calendar:',
        meetingBtn: 'Book a meeting',
        meetingFallback: 'We will contact you within 24 hours to arrange a convenient time for a call.',
        summary: 'Your inquiry',
        labels: { company: 'Business', name: 'Name', email: 'Email' },
        signoff: 'Best regards,<br><strong>The Metropolitan Digital team</strong>',
        autoNote: 'This is an automated message, but you can reply directly to this email.',
        pre: 'We received your inquiry – see the next step.'
    }
};


/* Бонус към автоматичните имейлове (само докато е в сила). Env: PROMO_TEXT, PROMO_UNTIL (ГГГГ-ММ-ДД). */
const PROMO_TEXT_DEFAULT = 'безплатно изготвяне на 3 рекламни визии (карусели за социалните мрежи) и текстове';
const BG_MONTHS = ['януари', 'февруари', 'март', 'април', 'май', 'юни', 'юли', 'август', 'септември', 'октомври', 'ноември', 'декември'];
function promoHtml(now) {
    const text = (process.env.PROMO_TEXT || PROMO_TEXT_DEFAULT).trim();
    const until = (process.env.PROMO_UNTIL || '2026-11-30').trim();
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(until);
    if (!text || !m) return '';
    const end = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 23, 59, 59));
    if ((now || new Date()) > end) return '';
    const dateTxt = `${+m[3]} ${BG_MONTHS[+m[2] - 1]}`;
    return `<div style="margin:24px 0 0;padding:14px 16px;border-radius:10px;background:#fdecea;border:1px solid #f3c6bf;">
        <p style="margin:0;font-size:15px;"><strong style="color:${COLORS.red};">Бонус до ${esc(dateTxt)}:</strong> ${esc(text)}. Ще се свържем с вас за детайлите.</p></div>`;
}

function buildClientEmail(lead, cfg) {
    const t = COPY[lead.lang];
    const isMeeting = lead.contact_preference === 'meeting';

    let next;
    if (isMeeting) {
        next = `<h2 style="margin:28px 0 8px;font-size:20px;color:${COLORS.dark};">${t.meetingTitle}</h2>
                <p style="margin:0;">${cfg.calendlyUrl ? t.meetingText : t.meetingFallback}</p>
                ${cfg.calendlyUrl ? button(cfg.calendlyUrl, t.meetingBtn) : ''}`;
    } else {
        const briefLink = `${cfg.briefUrl}${cfg.briefUrl.includes('?') ? '&' : '?'}name=${encodeURIComponent(lead.name)}&email=${encodeURIComponent(lead.email)}&company=${encodeURIComponent(lead.company)}&lang=${lead.lang}`;
        next = `<h2 style="margin:28px 0 8px;font-size:20px;color:${COLORS.dark};">${t.emailTitle}</h2>
                <p style="margin:0;">${t.emailText}</p>
                ${button(briefLink, t.emailBtn)}
                <p style="margin:0;">${t.emailPromise}</p>`;
    }

    const row = (k, v) =>
        `<tr><td style="padding:6px 12px 6px 0;color:${COLORS.muted};font-size:14px;vertical-align:top;white-space:nowrap;">${esc(k)}</td><td style="padding:6px 0;font-size:14px;">${v}</td></tr>`;

    const bodyHtml = `
        <p style="margin:0 0 16px;font-size:18px;">${t.hi(lead.name)}</p>
        <p style="margin:0;">${t.thanks}</p>
        ${next}
        ${lead.lang === 'bg' ? promoHtml() : ''}
        <hr style="border:0;border-top:1px solid #e3e6ea;margin:28px 0 16px;">
        <p style="margin:0 0 8px;font-size:13px;font-weight:bold;color:${COLORS.muted};text-transform:uppercase;letter-spacing:.06em;">${t.summary}</p>
        <table role="presentation" cellpadding="0" cellspacing="0">
            ${row(t.labels.company, esc(lead.company))}
            ${row(t.labels.name, esc(lead.name))}
            ${row(t.labels.email, esc(lead.email))}
        </table>
        <p style="margin:28px 0 0;">${t.signoff}</p>
        <p style="margin:16px 0 0;font-size:12px;color:${COLORS.muted};">${t.autoNote}</p>`;

    return {
        subject: t.subject(lead.name),
        html: shell({ siteUrl: cfg.siteUrl, preheader: t.pre, bodyHtml })
    };
}

function buildInternalEmail(lead, cfg) {
    const row = (k, v) =>
        `<tr><td style="padding:8px 14px 8px 0;color:${COLORS.muted};font-size:14px;vertical-align:top;white-space:nowrap;">${esc(k)}</td><td style="padding:8px 0;font-size:15px;">${v}</td></tr>`;

    const rows = [
        row('Бизнес', `<strong>${esc(lead.company)}</strong>`),
        row('Име', esc(lead.name)),
        row('Имейл', `<a href="mailto:${esc(lead.email)}" style="color:${COLORS.accent};">${esc(lead.email)}</a>`),
        row('Език', lead.lang === 'en' ? 'English' : 'Български'),
        row('Източник', esc(lead.source)),
        row('Получено', esc(lead.receivedAt))
    ].join('');

    const bodyHtml = `
        <p style="margin:0 0 4px;font-size:13px;font-weight:bold;color:${COLORS.red};text-transform:uppercase;letter-spacing:.06em;">Ново запитване</p>
        <h1 style="margin:0 0 16px;font-size:22px;color:${COLORS.dark};">${esc(lead.company)} &middot; ${esc(lead.name)}</h1>
        <table role="presentation" cellpadding="0" cellspacing="0" width="100%">${rows}</table>
        <p style="margin:20px 0 0;font-size:13px;color:${COLORS.muted};">Отговорът към този имейл отива директно при клиента. Автоматичният отговор с линк към брифа е изпратен отделно.</p>`;

    return {
        subject: `Ново запитване за оферта: ${lead.company} — ${lead.name}`,
        html: shell({ siteUrl: cfg.siteUrl, preheader: `${lead.company} · ${lead.name}`, bodyHtml })
    };
}

function buildBriefInternalEmail(brief, cfg) {
    const row = (k, v) =>
        `<tr><td style="padding:8px 14px 8px 0;color:${COLORS.muted};font-size:14px;vertical-align:top;white-space:nowrap;">${esc(k)}</td><td style="padding:8px 0;font-size:15px;">${v || '—'}</td></tr>`;
    const rows = [
        row('Име', esc(brief.name)),
        row('Имейл', `<a href="mailto:${esc(brief.email)}" style="color:${COLORS.accent};">${esc(brief.email)}</a>`),
        row('Фирма', esc(brief.company)),
        row('Уебсайт / социални мрежи', esc(brief.website)),
        row('Цели', esc(brief.goals).replace(/\n/g, '<br>')),
        row('Целева аудитория', esc(brief.audience).replace(/\n/g, '<br>')),
        row('Бюджет', esc(brief.budget)),
        row('Срок', esc(brief.deadline)),
        row('Допълнително', esc(brief.notes).replace(/\n/g, '<br>'))
    ].join('');
    const bodyHtml = `
        <p style="margin:0 0 4px;font-size:13px;font-weight:bold;color:${COLORS.red};text-transform:uppercase;letter-spacing:.06em;">Попълнен бриф</p>
        <h1 style="margin:0 0 16px;font-size:22px;color:${COLORS.dark};">${esc(brief.name)}${brief.company ? ' &middot; ' + esc(brief.company) : ''}</h1>
        <table role="presentation" cellpadding="0" cellspacing="0" width="100%">${rows}</table>
        <p style="margin:20px 0 0;font-size:13px;color:${COLORS.muted};">Клиентът очаква оферта до 24 часа.</p>`;
    return {
        subject: `Попълнен бриф: ${brief.name}${brief.company ? ' — ' + brief.company : ''} (оферта до 24ч)`,
        html: shell({ siteUrl: cfg.siteUrl, preheader: 'Попълнен бриф – оферта до 24 часа', bodyHtml })
    };
}

function buildBriefClientEmail(brief, cfg) {
    const bg = brief.lang !== 'en';
    const bodyHtml = `
        <p style="margin:0 0 16px;font-size:18px;">${bg ? 'Здравейте' : 'Hello'}, ${esc(brief.name)},</p>
        <p style="margin:0;">${bg
            ? 'Благодарим ви, че попълнихте брифа! Екипът на <strong>Metropolitan Digital</strong> го получи и ще изпрати персонализирана оферта <strong>до 24 часа</strong>.'
            : 'Thank you for completing the brief! The <strong>Metropolitan Digital</strong> team has received it and will send a tailored offer <strong>within 24 hours</strong>.'}</p>
        <p style="margin:24px 0 0;">${bg ? 'Поздрави,<br><strong>Екипът на Metropolitan Digital</strong>' : 'Best regards,<br><strong>The Metropolitan Digital team</strong>'}</p>`;
    return {
        subject: bg ? 'Получихме вашия бриф — оферта до 24 часа' : 'We received your brief — offer within 24 hours',
        html: shell({ siteUrl: cfg.siteUrl, preheader: bg ? 'Оферта до 24 часа' : 'Offer within 24 hours', bodyHtml })
    };
}

/* ─────────────────────────── Integrations ─────────────────────────── */

async function sendEmail(cfg, { to, replyTo, subject, html }) {
    const recipients = Array.isArray(to) ? to : [to];

    // Option A: SMTP (Gmail app password)
    if (cfg.smtpUser && cfg.smtpPass) {
        const nodemailer = require('nodemailer');
        const transport = nodemailer.createTransport({
            host: cfg.smtpHost,
            port: cfg.smtpPort,
            secure: cfg.smtpPort === 465,
            auth: { user: cfg.smtpUser, pass: cfg.smtpPass }
        });
        await transport.sendMail({ from: cfg.from, to: recipients.join(', '), replyTo, subject, html });
        return;
    }

    // Option B: Resend
    const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${cfg.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: cfg.from, to: recipients, reply_to: replyTo, subject, html })
    });
    if (!res.ok) {
        const text = await res.text().catch(() => '');
        throw new Error(`Resend ${res.status}: ${text.slice(0, 300)}`);
    }
}

async function insertRow(table, row, cfg) {
    const doInsert = (payload) =>
        fetch(`${cfg.supabaseUrl}/rest/v1/${table}`, {
            method: 'POST',
            headers: {
                apikey: cfg.supabaseKey,
                Authorization: `Bearer ${cfg.supabaseKey}`,
                'Content-Type': 'application/json',
                Prefer: 'return=minimal'
            },
            body: JSON.stringify(payload)
        });

    let res = await doInsert(row);
    if (!res.ok) {
        // Table may not have the newer columns yet (see supabase/leads_migration.sql).
        // Keep the lead anyway by folding the extra data into `message`.
        const errText = await res.text().catch(() => '');
        if (table === 'leads' && /column|schema cache|PGRST204/i.test(errText)) {
            // Drop the newer optional columns; the business name is already inside `message`.
            const { contact_preference, lang, source, phone, company, ...base } = row;
            res = await doInsert(base);
            if (res.ok) return;
        }
        throw new Error(`Supabase ${res.status}: ${errText.slice(0, 300)}`);
    }
}

/* ─────────────────────────── Handler ─────────────────────────── */

function attribLine(a) {
    if (!a || typeof a !== 'object') return '';
    const keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid', 'referrer', 'landing', 'page_url'];
    const parts = keys.filter((k) => a[k]).map((k) => `${k}=${String(a[k]).replace(/[\r\n]+/g, ' ').slice(0, 120)}`);
    return parts.length ? ` | ${parts.join('; ')}` : '';
}

exports.handler = async (event) => {
    if (event.httpMethod !== 'POST') return json(405, { ok: false, error: 'method_not_allowed' });

    let body;
    try {
        body = JSON.parse(event.body || '{}');
    } catch {
        return json(400, { ok: false, error: 'invalid_json' });
    }

    // Honeypot: real users never fill this hidden field. Pretend success for bots.
    if (body.website_url) return json(200, { ok: true, saved: false, ignored: true });

    const cfg = {
        apiKey: process.env.RESEND_API_KEY,
        smtpUser: (process.env.SMTP_USER || '').trim(),
        smtpPass: (process.env.SMTP_PASS || '').replace(/\s+/g, ''),
        smtpHost: process.env.SMTP_HOST || 'smtp.gmail.com',
        smtpPort: Number(process.env.SMTP_PORT) || 465,
        from: process.env.FROM_EMAIL,
        notifyEmail: (process.env.NOTIFY_EMAIL || process.env.SMTP_USER || '').split(',').map((s) => s.trim()).filter(Boolean),
        calendlyUrl: (process.env.CALENDLY_URL || '').trim(),
        siteUrl: (process.env.SITE_URL || 'https://metropolitandigital.bg').replace(/\/$/, ''),
        briefUrl: (process.env.BRIEF_URL || '').trim(),
        supabaseUrl: (process.env.SUPABASE_URL || DEFAULT_SUPABASE_URL).replace(/\/$/, ''),
        supabaseKey: process.env.SUPABASE_SERVICE_KEY || DEFAULT_SUPABASE_ANON
    };
    cfg.briefUrl = cfg.briefUrl || `${cfg.siteUrl}/brief`;
    if (!cfg.from && cfg.smtpUser) cfg.from = `Metropolitan Digital <${cfg.smtpUser}>`;
    const emailConfigured = Boolean(((cfg.smtpUser && cfg.smtpPass) || cfg.apiKey) && cfg.from && cfg.notifyEmail.length);

    const lang = body.lang === 'en' ? 'en' : 'bg';
    const receivedAt = new Date().toLocaleString('bg-BG', { timeZone: 'Europe/Sofia' });

    /* ---- Brief form ---- */
    if (body.type === 'brief') {
        const brief = {
            name: line(body.name, 120),
            email: line(body.email, 200).toLowerCase(),
            company: line(body.company, 160),
            website: line(body.website, 300),
            goals: clean(body.goals, 3000),
            audience: clean(body.audience, 1500),
            budget: line(body.budget, 120),
            deadline: line(body.deadline, 120),
            notes: clean(body.notes, 3000),
            lang
        };
        if (!brief.name || !EMAIL_RE.test(brief.email) || !brief.goals) return json(400, { ok: false, error: 'validation' });

        let saved = false;
        try {
            await insertRow('briefs', { ...brief, lang: undefined }, cfg);
            saved = true;
        } catch (err) {
            console.warn('Brief not saved to Supabase (table `briefs` may be missing):', err.message);
        }

        let notified = false;
        if (emailConfigured) {
            const internal = buildBriefInternalEmail(brief, cfg);
            const client = buildBriefClientEmail(brief, cfg);
            const results = await Promise.allSettled([
                sendEmail(cfg, { to: cfg.notifyEmail, replyTo: brief.email, ...internal }),
                sendEmail(cfg, { to: brief.email, replyTo: cfg.notifyEmail[0], ...client })
            ]);
            notified = results[0].status === 'fulfilled';
            results.forEach((r, i) => r.status === 'rejected' && console.error(`Brief email ${i === 0 ? 'internal' : 'client'} failed:`, r.reason.message));
        } else {
            console.error('Email is not configured (set SMTP_USER + SMTP_PASS, or RESEND_API_KEY + FROM_EMAIL).');
        }

        return saved || notified ? json(200, { ok: true, saved, notified }) : json(502, { ok: false, saved, notified });
    }

    /* ---- Funnels: audit / configurator / lead_magnet ---- */
    if (body.funnel) {
        const FUN = {
            audit: { label: 'Безплатен 48-ч видео одит', subject: 'Получихме заявката ви за видео одит',
                intro: 'Благодарим! Ще подготвим персонален Loom видео анализ на сайта или рекламния ви акаунт и ще ви го изпратим до 48 часа.' },
            configurator: { label: 'Конфигуратор: Пълен Дигитален Пакет', subject: 'Вашата персонална оферта — Metropolitan Digital',
                intro: 'Благодарим! Получихме отговорите ви от конфигуратора. Ще се върнем с конкретна оферта до 24 часа.' },
            lead_magnet: { label: 'Лийд магнит: чеклист за видеа', subject: 'Вашият чеклист: 15 сценария за конвертиращи Reels и TikTok видеа',
                intro: 'Благодарим! Вашият безплатен чеклист е готов за сваляне.' }
        };
        const meta = FUN[body.funnel];
        const email = line(body.email, 200).toLowerCase();
        if (!meta || !EMAIL_RE.test(email)) return json(400, { ok: false, error: 'validation' });
        const d = body.details && typeof body.details === 'object' ? body.details : {};
        const details = Object.keys(d).slice(0, 12).map((k) => `${line(k, 30)}: ${line(Array.isArray(d[k]) ? d[k].join(', ') : d[k], 200)}`).join(' | ');
        const companyOrSite = line(d.site_url, 160) || line(body.company, 160) || email.split('@')[1] || '';
        const fl = {
            name: line(body.name, 120) || email.split('@')[0], email, company: companyOrSite,
            service: meta.label, message: details + attribLine(body.attribution),
            budget: line(d.budget || d.monthly_budget, 80) || 'Не е посочен',
            contact_preference: 'email', lang, source: 'funnel-' + body.funnel
        };
        let saved = false;
        try { await insertRow('leads', fl, cfg); saved = true; } catch (err) { console.error('Funnel lead not saved:', err.message); }
        let notified = false, autoReplied = false;
        if (emailConfigured) {
            const rowH = (k, v) => `<tr><td style="padding:6px 14px 6px 0;color:${COLORS.muted};font-size:14px;white-space:nowrap;vertical-align:top;">${esc(k)}</td><td style="padding:6px 0;font-size:15px;">${v}</td></tr>`;
            const internalBody = `<p style="margin:0 0 4px;font-size:13px;font-weight:bold;color:${COLORS.red};text-transform:uppercase;">${esc(meta.label)}</p>
                <h1 style="margin:0 0 16px;font-size:22px;color:${COLORS.dark};">${esc(email)}</h1>
                <table role="presentation" width="100%">${rowH('Сайт/бизнес', esc(companyOrSite))}${rowH('Детайли', esc(details))}${rowH('Получено', esc(receivedAt))}</table>`;
            const lm = (process.env.LEAD_MAGNET_URL || '').trim(); // [ПОПЪЛНИ: публичен линк към PDF чеклиста]
            let cta = '';
            if (body.funnel === 'lead_magnet') cta = lm ? button(lm, 'Свали чеклиста (PDF)') : '';
            else if (cfg.calendlyUrl) cta = button(cfg.calendlyUrl, 'Запазете 15-минутна среща');
            const clientBody = `<p style="margin:0 0 12px;">Здравейте,</p><p style="margin:0 0 12px;">${esc(meta.intro)}</p>${cta}${body.funnel === 'configurator' ? promoHtml() : ''}<p style="margin:16px 0 0;color:${COLORS.muted};font-size:14px;">Ако имате въпроси, отговорете директно на този имейл.</p>`;
            const results = await Promise.allSettled([
                sendEmail(cfg, { to: cfg.notifyEmail, replyTo: email, subject: `${meta.label}: ${email}`, html: shell({ siteUrl: cfg.siteUrl, preheader: meta.label, bodyHtml: internalBody }) }),
                sendEmail(cfg, { to: email, replyTo: cfg.notifyEmail[0], subject: meta.subject, html: shell({ siteUrl: cfg.siteUrl, preheader: meta.subject, bodyHtml: clientBody }) })
            ]);
            notified = results[0].status === 'fulfilled'; autoReplied = results[1].status === 'fulfilled';
        }
        if (saved || notified) return json(200, { ok: true, saved, notified, autoReplied });
        return json(502, { ok: false, saved, notified, autoReplied });
    }

    /* ---- Contact / quote inquiry ---- */
    const lead = {
        name: line(body.name, 120),
        email: line(body.email, 200).toLowerCase(),
        company: line(body.company, 160),
        service: 'Заявка за оферта',
        contact_preference: 'email',
        lang,
        source: line(body.source, 60) || 'contact-form',
        receivedAt
    };

    if (!lead.name || !EMAIL_RE.test(lead.email) || !lead.company) {
        return json(400, { ok: false, error: 'validation' });
    }

    // 1) Save the lead (never block the emails on a database problem)
    let saved = false;
    try {
        await insertRow(
            'leads',
            {
                name: lead.name,
                email: lead.email,
                company: lead.company,
                service: lead.service,
                message: `Бизнес: ${lead.company}` + attribLine(body.attribution),
                budget: 'Не е посочен',
                contact_preference: lead.contact_preference,
                lang: lead.lang,
                source: lead.source
            },
            cfg
        );
        saved = true;
    } catch (err) {
        console.error('Lead not saved to Supabase:', err.message);
    }

    // 2) Internal notification + 3) client auto-responder (independent of each other)
    let notified = false;
    let autoReplied = false;
    if (emailConfigured) {
        const internal = buildInternalEmail(lead, cfg);
        const client = buildClientEmail(lead, cfg);
        const results = await Promise.allSettled([
            sendEmail(cfg, { to: cfg.notifyEmail, replyTo: lead.email, ...internal }),
            sendEmail(cfg, { to: lead.email, replyTo: cfg.notifyEmail[0], ...client })
        ]);
        notified = results[0].status === 'fulfilled';
        autoReplied = results[1].status === 'fulfilled';
        if (!notified) console.error('Internal notification failed:', results[0].reason.message);
        if (!autoReplied) console.error('Client auto-responder failed:', results[1].reason.message);
    } else {
        console.error('Email is not configured (set SMTP_USER + SMTP_PASS, or RESEND_API_KEY + FROM_EMAIL). Lead only saved to database.');
    }

    // Success for the visitor if the lead reached us in at least one reliable way.
    if (saved || notified) return json(200, { ok: true, saved, notified, autoReplied });
    return json(502, { ok: false, saved, notified, autoReplied });
};

module.exports._promoHtml = promoHtml;
