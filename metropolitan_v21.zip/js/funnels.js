/* Фунии: видео одит (form[data-funnel=audit]), лийд магнит (data-funnel=lead_magnet), конфигуратор (#md-configurator). */
(function () {
    'use strict';
    var CFG = window.MD_CONFIG || {};
    document.querySelectorAll('[data-price]').forEach(function (el) {
        var v = (CFG.PRICING || {})[el.getAttribute('data-price')];
        if (v) { el.textContent = 'от ' + v + ' €' + (el.getAttribute('data-per') || ''); el.classList.remove('todo'); }
    });
    function attr() { return window.mdAttribution ? window.mdAttribution() : {}; }
    function toast(m, t) { if (window.MDLeads) window.MDLeads.toast(m, t); else alert(m); }
    function go(funnel) { window.location.href = '/thank-you?f=' + encodeURIComponent(funnel); }

    async function send(funnel, email, details, name) {
        var payload = { funnel: funnel, email: email, name: name || email.split('@')[0], company: details.site_url || email.split('@')[1] || '', details: details, source: 'funnel-' + funnel, attribution: attr(), website_url: details._hp || '' };
        delete details._hp;
        var r = await window.MDLeads.submit(payload);
        try { var i = JSON.parse(sessionStorage.getItem('mdLeadInfo') || '{}'); i.funnel = funnel; sessionStorage.setItem('mdLeadInfo', JSON.stringify(i)); } catch (e) {}
        return r;
    }

    function wireForm(f) {
        f.addEventListener('submit', async function (e) {
            e.preventDefault();
            if (!f.reportValidity()) return;
            var btn = f.querySelector('button[type=submit]'), old = btn.textContent;
            btn.disabled = true; btn.textContent = 'Изпращане…';
            var d = {};
            f.querySelectorAll('[data-detail]').forEach(function (el) { d[el.getAttribute('data-detail')] = el.value; });
            d.page = location.pathname; d._hp = (f.querySelector('[name=website_url]') || {}).value || '';
            try {
                await send(f.getAttribute('data-funnel'), f.elements.email.value, d);
                go(f.getAttribute('data-funnel'));
            } catch (err) {
                toast('Не успяхме да изпратим формата. Моля, опитайте отново или пишете на office@metropolitandigital.bg.', 'error');
                btn.disabled = false; btn.textContent = old;
            }
        });
    }
    document.querySelectorAll('form[data-funnel]').forEach(wireForm);
    window.MDFunnels = { send: send, go: go };
})();
