/* Плаващ бутон за бърза връзка: обаждане / Viber / WhatsApp. Номерът е в js/config.js (QUICK_CONTACT). */
(function () {
    'use strict';
    var C = (window.MD_CONFIG || {}).QUICK_CONTACT || {};
    if (!C.phone) return;
    var p = String(C.phone).replace(/\D/g, ''), msg = encodeURIComponent('Здравейте! Искам оферта от metropolitandigital.bg');
    var w = document.createElement('div'); w.className = 'md-qc';
    w.innerHTML =
        '<div class="md-qc-menu" id="md-qc-menu" hidden>' +
        '<a href="tel:+' + p + '" data-cta="quick_call"><i class="fa-solid fa-phone" aria-hidden="true"></i> Обадете се' + (C.label ? ' <small>' + C.label + '</small>' : '') + '</a>' +
        '<a href="viber://chat?number=%2B' + p + '" data-cta="quick_viber"><i class="fa-brands fa-viber" aria-hidden="true"></i> Viber</a>' +
        '<a href="https://wa.me/' + p + '?text=' + msg + '" target="_blank" rel="noopener" data-cta="quick_whatsapp"><i class="fa-brands fa-whatsapp" aria-hidden="true"></i> WhatsApp</a></div>' +
        '<button type="button" class="md-qc-btn" aria-expanded="false" aria-controls="md-qc-menu" aria-label="Бърза връзка: обаждане, Viber, WhatsApp"><i class="fa-solid fa-comment-dots" aria-hidden="true"></i></button>';
    document.body.appendChild(w);
    var btn = w.querySelector('.md-qc-btn'), menu = w.querySelector('.md-qc-menu');
    function set(open) { menu.hidden = !open; btn.setAttribute('aria-expanded', String(open)); w.classList.toggle('is-open', open); }
    btn.addEventListener('click', function (e) { e.stopPropagation(); set(menu.hidden); });
    document.addEventListener('click', function (e) { if (!w.contains(e.target)) set(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { set(false); btn.focus(); } });
})();
