/**
 * Metropolitan Digital — Consent Mode v2 + tracking loader.
 * - Нищо за проследяване не се зарежда преди избор на посетителя.
 * - GA4 се зарежда след съгласие за "Аналитични", Meta Pixel — след "Маркетингови".
 * - Изчиства лични данни (name/email/company) от URL преди да се зареди какъвто и да е тракер.
 * ID-тата са от оригиналния сайт; ако използвате GTM, вижте docs/TRACKING-AND-FUNNEL.md.
 */
(function () {
    'use strict';
    var GA_ID = 'G-QEL23Z1MJH';
    var PIXEL_ID = '1518420283434841';
    var GTM_ID = (window.MD_CONFIG && window.MD_CONFIG.GTM_ID) || '';
    var KEY = 'md_consent_v1';
    var loaded = { ga: false, fb: false };

    /* ---------- 1) Изчистване на PII от URL (преди тракерите) ---------- */
    try {
        var q = new URLSearchParams(location.search);
        if (q.has('email') || q.has('name') || q.has('company')) {
            sessionStorage.setItem('mdPrefill', JSON.stringify({
                name: q.get('name') || '', email: q.get('email') || '', company: q.get('company') || ''
            }));
            ['email', 'name', 'company'].forEach(function (k) { q.delete(k); });
            var qs = q.toString();
            history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '') + location.hash);
        }
    } catch (e) {}

    /* ---------- 2) Consent Mode default = denied ---------- */
    window.dataLayer = window.dataLayer || [];
    function gtag() { window.dataLayer.push(arguments); }
    window.gtag = window.gtag || gtag;
    gtag('consent', 'default', {
        ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied',
        analytics_storage: 'denied', wait_for_update: 500
    });

    function read() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
    function save(c) { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {} }

    /* ---------- 3) Зареждане на тракери ---------- */
    function loadGTM() {
        if (loaded.gtm || !GTM_ID) return; loaded.gtm = true;
        window.dataLayer.push({ 'gtm.start': Date.now(), event: 'gtm.js' });
        var s = document.createElement('script'); s.async = true;
        s.src = 'https://www.googletagmanager.com/gtm.js?id=' + GTM_ID; document.head.appendChild(s);
    }
    function loadGA() {
        if (GTM_ID) { loadGTM(); return; }
        if (loaded.ga) return; loaded.ga = true;
        var s = document.createElement('script');
        s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA_ID;
        document.head.appendChild(s);
        gtag('js', new Date());
        gtag('config', GA_ID, { anonymize_ip: true });
    }
    function loadFB() {
        if (loaded.fb) return; loaded.fb = true;
        !function (f, b, e, v, n, t, s) {
            if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); };
            if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = [];
            t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s);
        }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
        window.fbq('init', PIXEL_ID);
        window.fbq('track', 'PageView');
    }

    function apply(c) {
        gtag('consent', 'update', {
            analytics_storage: c.analytics ? 'granted' : 'denied',
            ad_storage: c.marketing ? 'granted' : 'denied',
            ad_user_data: c.marketing ? 'granted' : 'denied',
            ad_personalization: c.marketing ? 'granted' : 'denied'
        });
        if (c.analytics) loadGA();
        if (c.marketing) { loadFB(); if (GTM_ID) loadGTM(); }
        window.dispatchEvent(new CustomEvent('md:consent', { detail: c }));
    }

    /* ---------- 4) Публичен API за събития ---------- */
    window.mdConsent = function () { return read() || { analytics: false, marketing: false }; };
    window.mdTrack = function (name, params) {
        params = params || {};
        window.dataLayer.push(Object.assign({ event: name }, params));
        var c = window.mdConsent();
        if (c.analytics && typeof window.gtag === 'function' && loaded.ga && !GTM_ID) window.gtag('event', name, params);
        if (c.marketing && typeof window.fbq === 'function') {
            var map = { generate_lead: 'Lead', brief_submitted: 'SubmitApplication', phone_click: 'Contact', email_click: 'Contact', calendly_booking: 'Schedule' };
            if (map[name]) window.fbq('track', map[name]); else window.fbq('trackCustom', name, params);
        }
    };

    /* Атрибуция (UTM / click ids) — само със съгласие за аналитика, иначе само за текущата страница */
    window.mdAttribution = function () {
        var out = {}, p = new URLSearchParams(location.search);
        ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'gclid', 'fbclid'].forEach(function (k) { if (p.get(k)) out[k] = p.get(k).slice(0, 120); });
        try {
            if (window.mdConsent().analytics) {
                var prev = JSON.parse(sessionStorage.getItem('mdAttrib') || '{}');
                out = Object.assign({ referrer: (document.referrer || '').slice(0, 200), landing: location.pathname }, prev, out);
                sessionStorage.setItem('mdAttrib', JSON.stringify(out));
            }
        } catch (e) {}
        out.page_url = location.pathname;
        return out;
    };

    /* ---------- 5) Банер ---------- */
    var BG = {
        title: 'Бисквитки и поверителност',
        text: 'Използваме необходими бисквитки за работата на сайта. С Вашето съгласие ползваме и аналитични (Google Analytics) и маркетингови (Meta Pixel) за измерване и реклама. Можете да промените избора си по всяко време.',
        all: 'Приемам всички', nec: 'Само необходими', set: 'Настройки', save: 'Запази избора',
        an: 'Аналитични', mk: 'Маркетингови', nc: 'Необходими (винаги активни)', more: 'Политика за поверителност'
    };
    var EN = {
        title: 'Cookies & privacy',
        text: 'We use necessary cookies to run the site. With your consent we also use analytics (Google Analytics) and marketing (Meta Pixel) cookies. You can change your choice at any time.',
        all: 'Accept all', nec: 'Necessary only', set: 'Settings', save: 'Save choice',
        an: 'Analytics', mk: 'Marketing', nc: 'Necessary (always on)', more: 'Privacy policy'
    };

    function banner(openSettings) {
        if (document.getElementById('md-consent')) return;
        var L = (localStorage.getItem('preferredLang') === 'en') ? EN : BG;
        var cur = window.mdConsent();
        var d = document.createElement('div');
        d.id = 'md-consent'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-live', 'polite'); d.setAttribute('aria-label', L.title);
        d.innerHTML =
            '<div class="mdc-in"><strong>' + L.title + '</strong><p>' + L.text + ' <a href="/privacy-policy">' + L.more + '</a></p>' +
            '<div class="mdc-set" ' + (openSettings ? '' : 'hidden') + '>' +
            '<label><input type="checkbox" checked disabled> ' + L.nc + '</label>' +
            '<label><input type="checkbox" id="mdc-an" ' + (cur.analytics ? 'checked' : '') + '> ' + L.an + '</label>' +
            '<label><input type="checkbox" id="mdc-mk" ' + (cur.marketing ? 'checked' : '') + '> ' + L.mk + '</label></div>' +
            '<div class="mdc-btns"><button type="button" id="mdc-all" class="mdc-p">' + L.all + '</button>' +
            '<button type="button" id="mdc-nec">' + L.nec + '</button>' +
            '<button type="button" id="mdc-set">' + (openSettings ? L.save : L.set) + '</button></div></div>';
        document.body.appendChild(d);
        function done(c) { c.ts = Date.now(); save(c); apply(c); d.remove(); }
        d.querySelector('#mdc-all').onclick = function () { done({ analytics: true, marketing: true }); };
        d.querySelector('#mdc-nec').onclick = function () { done({ analytics: false, marketing: false }); };
        d.querySelector('#mdc-set').onclick = function () {
            var box = d.querySelector('.mdc-set');
            if (box.hidden) { box.hidden = false; this.textContent = L.save; return; }
            done({ analytics: d.querySelector('#mdc-an').checked, marketing: d.querySelector('#mdc-mk').checked });
        };
    }

    var css = '#md-consent{position:fixed;left:16px;right:16px;bottom:16px;z-index:100000;max-width:720px;margin:0 auto;background:#0f1c2a;color:#fff;border:1px solid rgba(255,255,255,.15);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.45);font:14px/1.5 Montserrat,system-ui,sans-serif}' +
        '#md-consent .mdc-in{padding:18px 20px}#md-consent p{margin:6px 0 12px;color:#d5dbe3}#md-consent a{color:#CC361E;text-decoration:underline}' +
        '#md-consent .mdc-set{display:grid;gap:8px;margin-bottom:12px}#md-consent .mdc-set[hidden]{display:none}' +
        '#md-consent .mdc-btns{display:flex;gap:8px;flex-wrap:wrap}#md-consent button{cursor:pointer;border:1px solid rgba(255,255,255,.35);background:transparent;color:#fff;border-radius:8px;padding:10px 14px;font:600 13px Montserrat,system-ui,sans-serif;min-height:44px}' +
        '#md-consent button.mdc-p{background:#CC361E;border-color:#CC361E}#md-consent button:focus-visible{outline:2px solid #fff;outline-offset:2px}';

    function init() {
        var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
        var c = read();
        if (c) apply(c); else banner(false);
        document.addEventListener('click', function (e) {
            var t = e.target.closest && e.target.closest('[data-cookie-settings]');
            if (t) { e.preventDefault(); var old = document.getElementById('md-consent'); if (old) old.remove(); banner(true); }
            var a = e.target.closest && e.target.closest('a[href^="tel:"],a[href^="mailto:"]');
            if (a) window.mdTrack(a.href.indexOf('tel:') === 0 ? 'phone_click' : 'email_click', { page: location.pathname });
            var cta = e.target.closest && e.target.closest('[data-cta]');
            if (cta) window.mdTrack('cta_click', { cta_id: cta.getAttribute('data-cta'), page: location.pathname });
        });
        window.addEventListener('message', function (e) {
            if (e.origin && e.origin.indexOf('calendly.com') > -1 && e.data && e.data.event === 'calendly.event_scheduled') window.mdTrack('calendly_booking', { page: location.pathname });
        });
        var started = false;
        document.addEventListener('focusin', function (e) {
            var f = e.target.closest && e.target.closest('form');
            if (f && !started) { started = true; window.mdTrack('form_start', { form_id: f.id || 'form', page: location.pathname }); }
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
