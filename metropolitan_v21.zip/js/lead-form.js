/**
 * Lead Generation Flow — shared client logic (contact form, quote modal, brief form).
 *
 * Sends the inquiry to the Netlify function, which saves it, notifies the team
 * and sends the branded auto-responder. If the function is unreachable
 * (not deployed yet, offline), the lead is still saved straight to Supabase so
 * it is never lost.
 */
(function () {
    'use strict';

    const ENDPOINT = '/.netlify/functions/submit-lead';

    function lang() {
        return window.currentLang === 'en' ? 'en' : 'bg';
    }

    function t(key, fallback) {
        try {
            const v = window.translations && window.translations[lang()] && window.translations[lang()][key];
            return v || fallback;
        } catch (e) {
            return fallback;
        }
    }

    /** Small styled notification (replaces native alert()). */
    function toast(message, type) {
        const el = document.createElement('div');
        el.setAttribute('role', type === 'error' ? 'alert' : 'status');
        const bg = type === 'error' ? 'linear-gradient(135deg,#7a1f12,#CC361E)' : 'linear-gradient(135deg,#122435,#224766)';
        el.style.cssText =
            'position:fixed;top:24px;right:24px;left:24px;max-width:440px;margin-left:auto;z-index:99999;' +
            'background:' + bg + ';color:#fff;padding:18px 22px;border-radius:12px;' +
            'box-shadow:0 12px 40px rgba(0,0,0,.3);font-size:1rem;line-height:1.5;font-weight:600;' +
            'display:flex;gap:12px;align-items:flex-start;border-left:4px solid ' + (type === 'error' ? '#ffb4a8' : '#CC361E') + ';';
        const icon = document.createElement('i');
        icon.className = type === 'error' ? 'fa-solid fa-circle-exclamation' : 'fa-solid fa-circle-check';
        icon.style.cssText = 'font-size:1.3rem;margin-top:2px;';
        const text = document.createElement('span');
        text.textContent = message;
        el.appendChild(icon);
        el.appendChild(text);
        el.addEventListener('click', () => el.remove());
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 9000);
    }

    /** Insert a row; if the table lacks one of the newer columns, retry without them. */
    async function insertRow(table, row, optionalCols) {
        let { error } = await window.supabase.from(table).insert([row]);
        if (error && optionalCols && optionalCols.length && /column|schema cache|PGRST204/i.test(error.message || '')) {
            const base = Object.assign({}, row);
            optionalCols.forEach((c) => delete base[c]);
            ({ error } = await window.supabase.from(table).insert([base]));
        }
        if (error) {
            console.error('Supabase insert into "' + table + '" failed:', error);
            throw error;
        }
    }

    /** Direct-to-Supabase save (used when the Netlify function is not reachable). */
    async function fallbackSave(payload) {
        if (!window.supabase) throw new Error('no_backend');

        if (payload.type === 'brief') {
            await insertRow('briefs', {
                name: payload.name || '',
                email: payload.email || '',
                company: payload.company || null,
                website: payload.website || null,
                goals: payload.goals || null,
                audience: payload.audience || null,
                budget: payload.budget || null,
                deadline: payload.deadline || null,
                notes: payload.notes || null
            });
            return;
        }

        // The business name is also kept inside `message`, so nothing is lost even
        // if the `company` column has not been added to the table yet.
        await insertRow('leads', {
            name: payload.name,
            email: payload.email,
            company: payload.company,
            service: 'Заявка за оферта',
            message: 'Бизнес: ' + payload.company,
            budget: 'Не е посочен'
        }, ['company']);
    }

    /**
     * @returns {Promise<{ok:boolean, autoReplied:boolean, fallback:boolean}>}
     */
    async function submit(payload) {
        const body = Object.assign({ lang: lang(), attribution: (window.mdAttribution ? window.mdAttribution() : {}) }, payload);

        let res;
        try {
            res = await fetch(ENDPOINT, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
        } catch (networkErr) {
            res = null;
        }

        if (res && res.ok) {
            const data = await res.json().catch(() => ({}));
            return { ok: true, autoReplied: Boolean(data.autoReplied || data.notified), fallback: false };
        }

        // Validation problem: do not retry elsewhere.
        if (res && res.status === 400) throw new Error('validation');

        // Function missing / failing -> make sure the lead is not lost.
        console.warn('Lead function unavailable (' + (res ? res.status : 'network') + '). Saving directly to Supabase; no emails were sent.');
        await fallbackSave(body);
        return { ok: true, autoReplied: false, fallback: true };
    }

    function successMessage(payload, result) {
        if (result.autoReplied) {
            return t('lead_success_email', 'Благодарим ви! Изпратихме ви имейл с линк за кратък бриф – оферта до 24 часа.');
        }
        return t('alert_success', 'Благодарим ви! Вашето запитване е изпратено успешно и нашият екип ще се свърже с вас.');
    }

    // Brief submissions are tracked here; the lead conversion is tracked on thank-you.
    async function submitAndTrack(payload) {
        const result = await submit(payload);
        try {
            if (payload && payload.type === 'brief') {
                if (typeof window.mdTrack === 'function') window.mdTrack('brief_submitted', { page: location.pathname });
            } else {
                sessionStorage.setItem('mdLeadInfo', JSON.stringify({
                    name: payload.name || '', email: payload.email || '', company: payload.company || ''
                }));
                sessionStorage.removeItem('mdLeadTracked');
            }
        } catch (e) { /* must never break the form */ }
        return result;
    }

    /** After a successful lead: go to the separate "thank you" page. */
    function goToThanks() {
        window.location.href = 'thank-you';
    }

    window.MDLeads = { submit: submitAndTrack, goToThanks: goToThanks, toast: toast, successMessage: successMessage, t: t };
})();
