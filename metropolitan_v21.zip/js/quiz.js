/* Quiz от 3 стъпки + блок за гаранция/спешност. Зависи от js/funnels.js (window.MDFunnels). Без външни библиотеки. */
(function () {
    'use strict';
    var CFG = window.MD_CONFIG || {};
    function esc(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

    /* ---------- Гаранция + спешност (статичен и динамичен текст) ---------- */
    function promoEnd() {
        var now = new Date(), u = (CFG.PROMO || {}).until, e;
        if (u) { var p = u.split('-'); e = new Date(+p[0], +p[1] - 1, +p[2], 23, 59, 59); if (now > e) return null; }
        else e = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        return e.toLocaleDateString('bg-BG', { day: 'numeric', month: 'long' });
    }
    function trustActive() {
        var t = CFG.TRUST_TEST; if (!t || !t.days) return true;
        var p = String(t.start).split('-'), end = new Date(+p[0], +p[1] - 1, +p[2] + t.days, 0, 0, 0);
        return new Date() < end;
    }
    document.querySelectorAll('[data-md-trust]').forEach(function (el) {
        var compact = el.getAttribute('data-md-trust') === 'compact';
        var bonus = ((CFG.PROMO || {}).bonus || '').trim(), endTxt = promoEnd(), html = '';
        if (bonus && endTxt) html += '<p class="md-promo"><i class="fa-solid fa-gift" aria-hidden="true"></i> Заявки до ' + esc(endTxt) + ': ' + esc(bonus) + '</p>';
        if (trustActive()) {
            html += '<p class="md-guarantee"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i> Без риск: офертата е безплатна и без ангажимент. Ако предложението не ви отговаря, не дължите нищо.</p>';
            if (!compact) html += '<ul class="md-badges"><li><i class="fa-solid fa-ban" aria-hidden="true"></i> Без ангажимент</li><li><i class="fa-regular fa-clock" aria-hidden="true"></i> Отговор до 24 часа</li><li><i class="fa-solid fa-receipt" aria-hidden="true"></i> Прозрачна цена, без скрити такси</li></ul>';
        }
        if (!html) { el.hidden = true; return; }
        el.className = 'md-trust' + (compact ? ' md-trust--compact' : '');
        el.innerHTML = html;
    });

    /* ---------- Hook в началото на началната страница ---------- */
    document.querySelectorAll('[data-md-hook]').forEach(function (el) {
        var bonus = ((CFG.PROMO || {}).bonus || '').trim(), endTxt = promoEnd(), main, links;
        if (bonus && endTxt) {
            main = '<a class="hero-hook" href="#configurator-section" data-cta="hero_hook"><span class="hook-tag"><i class="fa-solid fa-gift" aria-hidden="true"></i> Бонус</span><span class="hook-txt">до ' + esc(endTxt) + ': ' + esc(((CFG.PROMO || {}).short || bonus)) + '</span><span class="hook-go">Вземи бонуса &rarr;</span></a>';
            links = 'Нови: <a href="/service-express" data-cta="hero_link_7days">Сайт до 7 дни</a> &middot; <a href="/service-seo#audit" data-cta="hero_link_audit">Безплатен видео одит</a>';
        } else {
            main = '<a class="hero-hook" href="/service-seo#audit" data-cta="hero_hook"><span class="hook-tag"><i class="fa-solid fa-video" aria-hidden="true"></i> Безплатно</span><span class="hook-txt">5-минутен видео анализ на сайта или рекламата ви до 48 часа</span><span class="hook-go">Поискай одит &rarr;</span></a>';
            links = 'Ново: <a href="/service-express" data-cta="hero_link_7days">Сайт до 7 дни</a> &middot; <a href="#configurator-section" data-cta="hero_link_quiz">Персонална оферта за 3 стъпки</a>';
        }
        el.innerHTML = main + '<p class="hero-hook-links">' + links + '</p>';
    });

    /* ---------- Quiz ---------- */
    var root = document.getElementById('md-quiz');
    if (!root || !window.MDFunnels) return;

    var SERVICES = [
        { t: 'Сайт или онлайн магазин', i: 'fa-laptop-code', kind: 'project' },
        { t: 'SEO и GEO (AI търсачки)', i: 'fa-chart-line', kind: 'monthly' },
        { t: 'Реклама в Google и Meta', i: 'fa-bullseye', kind: 'monthly' },
        { t: 'Социални мрежи и видео', i: 'fa-film', kind: 'monthly' },
        { t: 'Брандинг и дизайн', i: 'fa-pen-nib', kind: 'project' },
        { t: 'Пълен дигитален пакет', i: 'fa-layer-group', kind: 'monthly' },
        { t: 'Не съм сигурен — искам съвет', i: 'fa-circle-question', kind: 'monthly' }
    ];
    var SCALE = {
        project: { q: 'Какъв е мащабът на проекта?', opts: ['Малък проект', 'Среден проект', 'Голям проект', 'Още не знам'] },
        monthly: { q: 'Какъв месечен бюджет планирате?', opts: ['под 300 €', '300–1000 €', '1000–3000 €', 'над 3000 €'] }
    };
    var state = { service: null, kind: null, scale: null }, step = 0, busy = false;

    var bar, prog, stage;
    root.innerHTML = '<div class="qz"><div class="qz-bar" aria-hidden="true"><span></span></div><p class="qz-prog" aria-live="polite"></p><div class="qz-stage"></div></div>';
    bar = root.querySelector('.qz-bar span'); prog = root.querySelector('.qz-prog'); stage = root.querySelector('.qz-stage');

    function cardsHtml(list, cur, withIcons) {
        return '<div class="qz-grid' + (withIcons ? ' qz-grid--svc' : '') + '">' + list.map(function (o) {
            var label = o.t || o, icon = o.i ? '<i class="fa-solid ' + o.i + '" aria-hidden="true"></i>' : '';
            return '<button type="button" class="qz-card' + (cur === label ? ' is-on' : '') + '" data-v="' + esc(label) + '" aria-pressed="' + (cur === label) + '">' + icon + '<span>' + esc(label) + '</span></button>';
        }).join('') + '</div>';
    }
    function stepHtml(n) {
        if (n === 0) return '<fieldset class="qz-fs"><legend tabindex="-1">Какво ви трябва?</legend>' + cardsHtml(SERVICES, state.service, true) + '</fieldset>';
        if (n === 1) { var s = SCALE[state.kind]; return '<fieldset class="qz-fs"><legend tabindex="-1">' + s.q + '</legend>' + cardsHtml(s.opts, state.scale, false) + '</fieldset><div class="qz-actions"><button type="button" class="btn-secondary" data-back>Назад</button></div>'; }
        return '<form class="qz-form" novalidate><h3 tabindex="-1">Последна стъпка</h3><p class="qz-sum">' + esc(state.service) + ' · ' + esc(state.scale) + '</p>' +
            '<label for="qz-name">Име</label><input id="qz-name" name="name" type="text" required autocomplete="name" maxlength="120" placeholder="Вашето име">' +
            '<label for="qz-email">Имейл</label><input id="qz-email" name="email" type="email" required autocomplete="email" maxlength="200" placeholder="name@company.bg">' +
            '<input type="text" name="website_url" tabindex="-1" autocomplete="off" aria-hidden="true" style="display:none">' +
            '<button type="submit" class="btn-primary btn-large" data-cta="quiz_submit">Вземи персонална оферта</button>' +
            '<p class="qz-note">Изпращайки формата, се съгласявате с <a href="/privacy-policy">Политиката за поверителност</a>.</p>' +
            '<div class="qz-actions"><button type="button" class="btn-secondary" data-back>Назад</button></div></form>';
    }
    function bind(el) {
        el.querySelectorAll('.qz-card').forEach(function (b) {
            b.onclick = function () {
                if (busy) return; var v = b.getAttribute('data-v');
                el.querySelectorAll('.qz-card').forEach(function (x) { x.classList.remove('is-on'); x.setAttribute('aria-pressed', 'false'); });
                b.classList.add('is-on'); b.setAttribute('aria-pressed', 'true');
                if (step === 0) { var svc = SERVICES.filter(function (s) { return s.t === v; })[0]; if (state.service !== v) state.scale = null; state.service = v; state.kind = svc.kind; }
                else state.scale = v;
                setTimeout(function () { go(step + 1, 1); }, 200);
            };
        });
        var back = el.querySelector('[data-back]'); if (back) back.onclick = function () { go(step - 1, -1); };
        var f = el.querySelector('form');
        if (f) f.addEventListener('submit', async function (e) {
            e.preventDefault(); if (!f.reportValidity()) return;
            var btn = f.querySelector('button[type=submit]'); btn.disabled = true; btn.textContent = 'Изпращане…';
            try {
                await window.MDFunnels.send('configurator', f.elements.email.value, { service: state.service, scale_or_budget: state.scale, page: location.pathname, _hp: f.elements.website_url.value }, f.elements.name.value);
                window.mdTrack && window.mdTrack('configurator_complete', { service: state.service });
                window.MDFunnels.go('configurator');
            } catch (err) {
                if (window.MDLeads) window.MDLeads.toast('Не успяхме да изпратим заявката. Опитайте отново или пишете на office@metropolitandigital.bg.', 'error');
                btn.disabled = false; btn.textContent = 'Вземи персонална оферта';
            }
        });
    }
    function go(n, dir) {
        if (busy) return; busy = true;
        var old = stage.querySelector('.qz-step'), el = document.createElement('div');
        el.className = 'qz-step ' + (dir > 0 ? 'qz-in-fwd' : dir < 0 ? 'qz-in-back' : '');
        el.innerHTML = stepHtml(n); step = n; bind(el);
        if (old) { old.classList.add('qz-out'); old.setAttribute('aria-hidden', 'true'); setTimeout(function () { old.remove(); }, 200); }
        stage.appendChild(el);
        bar.style.width = ((n + 1) / 3 * 100) + '%'; prog.textContent = 'Стъпка ' + (n + 1) + ' от 3';
        window.mdTrack && dir && window.mdTrack('quiz_step', { step: n + 1 });
        setTimeout(function () { busy = false; var h = el.querySelector('legend,h3'); if (h && dir) h.focus({ preventScroll: true }); }, 320);
    }
    go(0, 0);
})();
