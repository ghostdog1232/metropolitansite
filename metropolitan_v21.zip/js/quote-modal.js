/**
 * Quote Modal — Metropolitan Digital
 * Manages the "Вземи оферта" popup form across all pages.
 */

(function () {
    'use strict';

    // ── Inject Modal HTML ──────────────────────────────────────────────────────
    function injectModal() {
        if (document.getElementById('quoteModal')) return;

        const modalHTML = `
<div id="quoteModal" class="quote-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="quoteModalTitle">
    <div class="quote-modal-box">
        <button class="quote-modal-close" onclick="closeQuoteModal()" aria-label="Затвори">
            <i class="fa-solid fa-xmark"></i>
        </button>

        <div class="quote-modal-header">
            <div class="quote-modal-icon">
                <i class="fa-solid fa-file-invoice-dollar"></i>
            </div>
            <h2 id="quoteModalTitle">Вземи безплатна оферта</h2>
            <p>Оставете данни за контакт и ще получите оферта до 24 часа.</p>
        </div>

        <form class="quote-modal-form" id="quoteModalForm" novalidate>
            <div class="qm-field">
                <label for="qm-company">Име на бизнеса *</label>
                <input type="text" id="qm-company" name="company" placeholder="Вашата фирма" required autocomplete="organization" maxlength="160">
            </div>

            <div class="qm-field">
                <label for="qm-name">Вашето Име *</label>
                <input type="text" id="qm-name" name="name" placeholder="Иван Иванов" required autocomplete="name" maxlength="120">
            </div>

            <div class="qm-field">
                <label for="qm-email">Имейл Адрес *</label>
                <input type="email" id="qm-email" name="email" placeholder="ivan@firma.bg" required autocomplete="email" maxlength="200">
            </div>

            <div class="hp-field" aria-hidden="true" style="display:none">
                <label>Website <input type="text" id="qm-website-url" name="website_url" tabindex="-1" autocomplete="off"></label>
            </div>

            <button type="submit" class="btn-primary qm-submit" id="qm-submit-btn">
                <i class="fa-solid fa-paper-plane"></i>
                <span>Получи оферта</span>
            </button>

            <p class="qm-privacy">
                <i class="fa-solid fa-lock"></i>
                Вашата информация е защитена и няма да бъде споделяна с трети страни.
            </p>
        </form>
    </div>
</div>`;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
        bindQuoteForm();
    }

    // ── Form Submit ────────────────────────────────────────────────────────────
    function bindQuoteForm() {
        const form = document.getElementById('quoteModalForm');
        if (!form) return;

        form.addEventListener('submit', async function (e) {
            e.preventDefault();

            const btn = document.getElementById('qm-submit-btn');
            const btnSpan = btn.querySelector('span');
            const originalText = btnSpan.textContent;

            btn.disabled = true;
            btnSpan.textContent = 'Изпращане...';
            btn.querySelector('i').className = 'fa-solid fa-spinner fa-spin';

            const payload = {
                company: document.getElementById('qm-company').value.trim(),
                name: document.getElementById('qm-name').value.trim(),
                email: document.getElementById('qm-email').value.trim(),
                website_url: document.getElementById('qm-website-url').value,
                source: 'quote-modal'
            };

            try {
                const result = await window.MDLeads.submit(payload);

                form.reset();
                closeQuoteModal();
                window.MDLeads.goToThanks();
            } catch (err) {
                console.error('Quote form error:', err);
                window.MDLeads.toast(
                    err && err.message === 'validation'
                        ? 'Моля, проверете попълнените данни и опитайте отново.'
                        : 'Възникна грешка. Моля, опитайте отново или ни пишете директно.',
                    'error'
                );
            } finally {
                btn.disabled = false;
                btnSpan.textContent = originalText;
                btn.querySelector('i').className = 'fa-solid fa-paper-plane';
            }
        });
    }

    // ── Inline success (for pages without successModal) ───────────────────────
    function showInlineSuccess() {
        const el = document.createElement('div');
        el.style.cssText = `
            position: fixed; top: 30px; right: 30px; z-index: 99999;
            background: linear-gradient(135deg, #1a5c3a, #2a8c5c);
            color: #fff; padding: 20px 28px; border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            font-family: var(--font-main, sans-serif);
            font-size: 1rem; font-weight: 600;
            display: flex; align-items: center; gap: 12px;
            animation: slideInRight 0.4s ease;
        `;
        el.innerHTML = '<i class="fa-solid fa-check-circle" style="font-size:1.4rem;"></i> Запитването е изпратено успешно!';
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 4000);
    }

    // ── Public API ─────────────────────────────────────────────────────────────
    window.openQuoteModal = function () {
        const modal = document.getElementById('quoteModal');
        if (!modal) return;

        modal.classList.add('active');
        document.body.style.overflow = 'hidden';

        // Focus first field
        setTimeout(() => {
            const first = modal.querySelector('input, select, textarea');
            if (first) first.focus();
        }, 300);
    };

    window.closeQuoteModal = function () {
        const modal = document.getElementById('quoteModal');
        if (!modal) return;
        modal.classList.remove('active');
        document.body.style.overflow = '';
    };

    // ── Click outside to close ─────────────────────────────────────────────────
    document.addEventListener('click', function (e) {
        const modal = document.getElementById('quoteModal');
        if (modal && e.target === modal) {
            window.closeQuoteModal();
        }
    });

    // ── ESC to close ──────────────────────────────────────────────────────────
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') window.closeQuoteModal();
    });

    // ── Auto-init on DOM ready ────────────────────────────────────────────────
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', injectModal);
    } else {
        injectModal();
    }
})();
